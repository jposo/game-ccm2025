﻿namespace GenericProject.Utilities
{
    using GenericProject.Models.ViewModels;
    using OfficeOpenXml;
    using System.Collections.Generic;
    using System.IO;
    using System.Linq;

    public class ExcelReportGenerator
    {
        public void GenerateExcelReport(string filePath, List<TablePensionablesViewModel> data)
        {
            FileInfo file = new FileInfo(filePath);

            using (ExcelPackage package = new ExcelPackage(file))
            {
                // Create the sheet
                ExcelWorksheet sheet = package.Workbook.Worksheets.Add("Pensionables");

                // Map the Model data to the ViewModel (if needed)
                //List<Pensionable> viewModelList = data.Select(model => new Pensionable(model)).ToList();

                // Load data into the sheet from the Model (if needed)
                sheet.Cells.LoadFromCollection(data, true);

                package.Save();
            }
        }
    }
}
