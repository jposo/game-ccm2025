﻿using GenericProject.Areas.Identity.Data;
using GenericProject.Data;
using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;

namespace GenericProject.Utilities
{
    public class GetUser
    {
        private readonly IHttpContextAccessor _httpContextAccessor;
        private readonly ApplicationContext _context;
        public GetUser(ApplicationContext context, IHttpContextAccessor httpContextAccessor)
        {
            _context = context;
            _httpContextAccessor = httpContextAccessor;
        }
        public User CurrentUser()
        {
            if (_httpContextAccessor.HttpContext.User == null)
                return null;

            string userName = _httpContextAccessor.HttpContext.User.Identity.Name;
            
            var user = _context.Users.FirstOrDefault(x => x.Email == userName);

            return user;
        }
    }
}
