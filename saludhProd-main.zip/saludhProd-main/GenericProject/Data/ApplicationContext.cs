﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using GenericProject.Areas.Identity.Data;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using GenericProject.Models;

namespace GenericProject.Data
{
    public class ApplicationContext : IdentityDbContext<User>
    {
        public ApplicationContext(DbContextOptions<ApplicationContext> options)
            : base(options)
        {
        }

        protected override void OnModelCreating(ModelBuilder builder)
        {
            base.OnModelCreating(builder);
            // Customize the ASP.NET Identity model and override the defaults if needed.
            // For example, you can rename the ASP.NET Identity table names and more.
            // Add your customizations after calling base.OnModelCreating(builder);
        }

        public DbSet<GenericProject.Models.TesmamentedPeople> TesmamentedPeople { get; set; }

        public DbSet<GenericProject.Models.Employee> Employee { get; set; }

        public DbSet<GenericProject.Models.EconomicDependant> EconomicDependant { get; set; }

        public DbSet<GenericProject.Models.FileManager> FileManager { get; set; }

        public DbSet<GenericProject.Models.Appointment> Appointment { get; set; }

        public DbSet<GenericProject.Models.LaboratoryDocuments> LaboratoryDocuments { get; set; }

        public DbSet<GenericProject.Models.FilePensionables> FilePensionables  { get; set; }

        public DbSet<GenericProject.Models.ControlTable> ControlTable { get; set; }

        public DbSet<GenericProject.Models.FilesStep1> FilesStep1{ get; set; }

        public DbSet<GenericProject.Models.FilesStep2> FilesStep2{ get; set; }

        public DbSet<GenericProject.Models.ExcelAll> ExcelAll { get; set; }

        public DbSet<GenericProject.Models.Retired> Retired { get; set; }
        
        public DbSet<GenericProject.Models.Pensionable> Pensionable { get; set; }
    }
}
