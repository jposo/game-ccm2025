﻿namespace GenericProject.Models
{
    using System;
    using System.ComponentModel.DataAnnotations;

    public class FileModel
    {
        public int Id { get; set; }

        public string FileName { get; set; }

        [Display(Name = "Nombre(s)")]
        public string Name { get; set; }
        
        public FileTypes FileType { get; set; }

        [DisplayFormat(DataFormatString = "{0:dd/MM/yyyy}", ApplyFormatInEditMode = true)]
        [Display(Name = "Fecha de captura")]
        public DateTime CreationDate { get; set; } = DateTime.Now;

        public bool IsDeleted { get; set; } = false;

        public Pensionable Pensionable  { get; set; }
        public int PensionableId { get; set; }
    }

    public enum FileTypes
    {
        PasoUno = 1,
        PasoDos = 2
    }
}