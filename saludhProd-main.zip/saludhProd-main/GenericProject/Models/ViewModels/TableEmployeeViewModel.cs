﻿namespace GenericProject.Models.ViewModels
{
    public class TableEmployeeViewModel
    {
        public TableEmployeeViewModel(Employee employee)
        {
            Id = employee.Id.ToString();
            EmployeeNumber = employee.EmployeeNumber;
            Name = employee.Name;
            PLastName = employee.PLastName;
            MLastName = employee.MLastName;
            Adscripcion = employee.Adscripcion;
            RFC = employee.RFC;
            CURP = employee.CURP;
            IsVerified = employee.IsVerified;
            IsQuoted = employee.IsQuoted;
        }

        public string Id { get; set; }
        public string EmployeeNumber { get; set; }
        public string Name { get; set; }
        public string PLastName { get; set; }
        public string MLastName { get; set; }
        public string Adscripcion { get; set; }
        public string RFC { get; set; }
        public string CURP { get; set; }
        public bool? IsVerified { get; set; }
        public bool? IsQuoted { get; set; }

    }
}
