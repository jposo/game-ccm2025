﻿using GenericProject.Migrations;
using Microsoft.AspNetCore.Http;
using Nancy;
using NPOI.SS.Formula.Functions;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.IO;
using System.Linq;

namespace GenericProject.Models.ViewModels
{
    public class TableReportPensionableViewModel
    {
        public string EmployeeNumber { get; set; }
        public string Name { get; set; }
        public string PLastName { get; set; }
        public string MLastName { get; set; }
        public StatusPensionable Status { get; set; }
        public string Pension { get; set; }
        public typesPension TypePension { get; set; }
        public Jobs Job { get; set; }
        public List<FilePensionables> FilePensionables { get; set; }


    }
    

}
