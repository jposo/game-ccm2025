﻿using GenericProject.Migrations;
using Microsoft.AspNetCore.Http;
using Nancy;
using NPOI.SS.Formula.Functions;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.IO;
using System.Linq;

namespace GenericProject.Models.ViewModels
{
    public class TablePensionablesViewModel
    {
        
        public TablePensionablesViewModel(int id, int _step, Pensionable? pensionable=null)
        {
            this.EmployeeId = id;
            this.Step = _step;
            if(pensionable != null)
                this.pensionable = pensionable;
        }
        public TablePensionablesViewModel() {
            
        }

        public Pensionable pensionable { get; set; }
        public string EmployeeNumber { get; set; }

        public int EmployeeId { get; set; }
        public List<string> NameDocInfo { get; set; }

        public List<FilePensionables> FilesPensionable { get; set; }

        public virtual ICollection<Pensionable> Pensionables { get; set; } // Navigation property

        public string checkPrePension { get; set; }

        public IFormFile prePension { get; set; }

        public IFormFile HojaAportacion { get; set; }

        public IFormFile CartaCompromiso { get; set; }
        public string checkSituacionFiscal { get; set; }
        public IFormFile SituacionFiscal { get; set; }

        public string ClasePension { get; set; }

        public IFormFile FichaTecnica { get; set; }

        public IFormFile CartaAlcalde { get; set; }

        public IFormFile FormatoIngreso { get; set; }

        //public IFormFile StatusGenerales { get; set; }

        public IFormFile SolicitudISSSTESON { get; set; }

        public IFormFile ActaNacimiento { get; set; }

        public IFormFile HojaServicio { get; set; }

        //public IFormFile Foto { get; set; }

        public IFormFile CURP { get; set; }

        public IFormFile INE { get; set; }

        public IFormFile Talon { get; set; }
        public string checkRFC { get; set; }
        public IFormFile RFC { get; set; }
        //public string checkHojaAyuntamiento { get; set; }

        public IFormFile HojaAyuntamiento { get; set; }

        public IFormFile FichaPermiso { get; set; }
        public IFormFile DictamenMed { get; set; }
        public string checkNomed { get; set; }
        public IFormFile IngresoPensiones { get; set; }
        
        public string checkNoSindicato { get; set; }
        public string NumeroSindicato { get; set; }

        public string TipoPension { get; set; }

        public string FechaPermisoPreJubilatorio { get; set; }

        public string Analisis { get; set; }

        public string Dictamen { get; set; }

        public string TrabajoSocial { get; set; }

        public string Juridico { get; set; }

        public string ProcesoResolucion { get; set; }

        public string AprobadoJunta { get; set; }

        public string PrimerPago { get; set; }

        public IFormFile AcuerdoAdmin { get; set; }

        public IFormFile SolicitudJuridica { get; set; }

        public IFormFile TurnarJuridicoRH { get; set; }

        public IFormFile InformarBaja { get; set; }

        public IFormFile OpinionJuridica { get; set; }

        public string TurnarAsuntosLaborales { get; set; }

        public IFormFile SolicitudReunion { get; set; }
        public string SolicitudReunionNA { get; set; }

        public string MontoPension { get; set; }

        public IFormFile RespuestaJuridica { get; set; }

        public IFormFile RecepcionCabildo { get; set; }

        public IFormFile InfAreaAlta { get; set; }

        public IFormFile FondoRetiro { get; set; }
        public string FondoRetiroNA { get; set; }

        public IFormFile CalculoPension { get; set; }
        
        public bool CasoCerrado { get; set; }
        
        public List<GenericProject.Models.ControlTable> ControlTable { get; set; }

        public List<FileViewModel> Files { get; set; }

        public List<InfoViewModel> Info { get; set; }

        public List<GenericProject.Models.ControlTable> Table { get; set; }

        public string SelectedPension { get; set; }

        public int Step { get; set; }
    }

    public class FileViewModel
    {
        public string NameDocFiles { get; set; }
        public IFormFile UrlFile { get; set; }
        public int Number { get; set; }
        public bool isFile { get; set; } = true;
    }
    public class FilesViewModel
    {
        public string Employee { get; set; }
        public string NameDocFiles { get; set; }
        public IFormFile UrlFile { get; set; }
        public string TipoPension { get; set; }
        public int  Steps { get; set; }
    }

    public class InfoViewModel
    {
        public string NameDocInfo { get; set; }
        public string Info { get; set; }
        public int Number { get; set; }
        public bool isFile { get; set; } = false;
    }

    public enum Tipos
    {
        ClasePension = 1,
        FichaTecnica = 2,
        CartaAlcalde = 3,
        FormatoIngreso = 4,
        StatusGenerales = 5,
        SolicitudISSSTESON = 6,
        ActaNacimiento = 7,
        HojaServicio = 8,
        HojaAportacion = 9,
        Foto = 10,
        CURP = 11,
        INE = 12,
        Talon = 13,
        RFC = 14,
        CartaCompromiso = 15,
        HojaAyuntamiento = 16,
        FichaPermiso = 17,
        IngresoPensiones = 18,
        NumeroSindicato = 19,
        TipoPension = 20,
        FechaPermisoPreJubilatorio = 21,
        Analisis = 22,
        Dictamen = 23,
        TrabajoSocial = 24,
        Juridico = 25,
        ProcesoResolucion = 26,
        AprobadoJunta = 27,
        PrimerPago = 28,
        AcuerdoAdmin = 29,
        SolicitudJuridica = 30,
        TurnarJuridicoRH = 31,
        InformarBaja = 32,
        OpinionJuridica = 33,
        TurnarAsuntosLaborales = 34,
        SolicitudReunion = 35,
        RespuestaJuridica = 36,
        RecepcionCabildo = 37,
        InfAreaAlta = 38,
        FondoRetiro = 39,
        CasoCerrado = 40,
        prePension = 45,
        CalculoPension = 46,
        MontoPension = 47,
        SituacionFiscal=48,
        DictamenMed =49
    }
}
