﻿namespace GenericProject.Models
{
    using GenericProject.Models.ViewModels;
    using Microsoft.AspNetCore.Http;
    using System;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;

    public class FilePensionables
    {
        public int Id { get; set; }

        public int EmployeeId { get; set; }

        public int Number { get; set; }

        public string NameDoc { get; set; }

        public string Info { get; set; }

        public bool IsFile { get; set; }
        
        public int Step { get; set; }

        public Tipos Tipo{ get; set; }

        public bool IsDeleted { get; set; } = false;
        //public bool IsModified { get; set; } = false;
        [NotMapped] 
        public IFormFile? file { get; set; }
        public DateTime? UploadedDate { get; set; } = DateTime.Now;
    }

    public class ControlTable
    {
        public int Id { get; set; }
        
        public int Step { get; set; }

        public string Name { get; set; }

        public bool NecesaryStep1 { get; set; } = true;
    }

    public class FilesStep1
    {
        public int Id { get; set; }

        [Display(Name = "Id de Empleado")]
        public int? EmployeeId { get; set; }

        [Display(Name = "Número de Empleado")]
        public string? EmployeeNumber { get; set; }

        [Display(Name = "Empleado")]
        public virtual
#nullable disable
        Pensionable Pensionable
        { get; set; } = new Pensionable();

        [Display(Name = "Clase de pensión")]
        public string ClassPension { get; set; }

        [Display(Name = "Ficha técnica")]
        public string FileFichaTecnica { get; set; }

        [NotMapped]
        public IFormFile DocFichaTecnica { get; set; }

        [Display(Name = "Carta alcalde")]
        public string FileCartaAlcalde { get; set; }

        [NotMapped]
        public IFormFile DocCartaAlcalde { get; set; }

        [Display(Name = "Formato de Ingreso")]
        public string FileFormatoIngreso { get; set; }

        [NotMapped]
        public IFormFile DocFormatoIngreso { get; set; }

        [Display(Name = "Estatus Generales")]
        public string FileEstatusGenerales { get; set; }

        [NotMapped]
        public IFormFile DocEstatusGenerales { get; set; }

        [Display(Name = "Solicitud de Pensión ISSSTESON")]
        public string FileSolicitudIsssteson { get; set; }

        [NotMapped]
        public IFormFile DocSolicitudIsssteson { get; set; }

        [Display(Name = "Acta nacimiento")]
        public string FileActaNacimiento { get; set; }

        [NotMapped]
        public IFormFile DocActaNacimiento { get; set; }

        [Display(Name = "Hoja de servicio")]
        public string FileHojaServicio { get; set; }

        [NotMapped]
        public IFormFile DocHojaServicio { get; set; }

        [Display(Name = "Hoja de aportación reciente (6 meses)")]
        public string FileHojaAportacion { get; set; }

        [NotMapped]
        public IFormFile DocHojaAportacion { get; set; }

        [Display(Name = "Fotografía infantil o credencial")]
        public string FileFoto { get; set; }

        [NotMapped]
        public IFormFile DocFoto { get; set; }

        [Display(Name = "CURP")]
        public string FileCURP { get; set; }

        [NotMapped]
        public IFormFile DocCURP { get; set; }

        [Display(Name = "INE")]
        public string FileINE { get; set; }

        [NotMapped]
        public IFormFile DocINE { get; set; }

        [Display(Name = "Talón de cheque")]
        public string FileTalon { get; set; }

        [NotMapped]
        public IFormFile DocTalon { get; set; }

        [Display(Name = "Certificado de RFC")]
        public string FileRFC { get; set; }

        [NotMapped]
        public IFormFile DocRFC { get; set; }

        [Display(Name = "Carta de compromiso")]
        public string FileCartaCompromiso { get; set; }

        [NotMapped]
        public IFormFile DocCartaCompromiso { get; set; }

        [Display(Name = "Hoja de servicio del ayuntamiento")]
        public string FileHojaAyuntamiento { get; set; }

        [NotMapped]
        public IFormFile DocHojaAyuntamiento { get; set; }

        [Display(Name = "Dictamen Médico")]
        public string FileDictamenMed { get; set; }

        [NotMapped]
        public IFormFile DocDictamenMed { get; set; }

        public bool IsDeleted { get; set; }
    }

    public class FilesStep2
    {
        public int Id { get; set; }

        [Display(Name = "Id de Empleado")]
        public int? EmployeeId { get; set; }

        [Display(Name = "Ficha de permiso")]
        public string FileFichaPermiso { get; set; }
        [NotMapped]
        public IFormFile DocFichaPermiso { get; set; }

        [Display(Name = "Ingreso a permiso de Pensiones")]
        public string FileIngresoPermiso { get; set; }
        [NotMapped]
        public IFormFile DocIngresoPermiso { get; set; }

        [Display(Name = "Número de sindicato")]
        public int SyndicateNumber { get; set; }

        [Display(Name = "Responsable de pensión")]
        public TypeResponsible Responsible { get; set; }

        [Display(Name = "Fecha de permiso prejubilatorio")]
        public DateTime? DateRetired { get; set; }

        public bool IsDeleted { get; set; } = false;
    }

    public enum LaboralThings
    {
        Porcentaje,
        [Display(Name = "No Aplica")]
        NoApply,
    }

    public enum Cabildo
    {
        Documento,
        [Display(Name = "No Aplica")]
        NoApply,
    }
}