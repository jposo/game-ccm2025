﻿namespace GenericProject.Models
{
    using Microsoft.AspNetCore.Http;
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using Newtonsoft.Json;
    using GenericProject.Models.ViewModels;

    public class Employee
    {

        public int Id { get; set; }
        public string UserId { get; set; }

        [DisplayFormat(DataFormatString = "{0:dd/MM/yyyy}", ApplyFormatInEditMode = true)]
        [Display(Name = "Fecha de captura")]
        public DateTime CreationDate { get; set; } = DateTime.Now;

        [Display(Name = "Nombre(s)")]
        public string Name { get; set; }

        [Display(Name = "Apellido Paterno")]
        public string PLastName { get; set; }

        [Display(Name = "Apellido Materno")]
        public string MLastName { get; set; }

        [Display(Name = "Correo Electrónico")]
        public string? EmailE { get; set; }

        [Display(Name = "Teléfono particular")]
        public int? Tel { get; set; }

        [Display(Name = "Teléfono Celular")]
        public int? Cel { get; set; }

        [Display(Name = "Adscripción")]
        public string? Adscripcion { get; set; }

        [Display(Name = "Dirección (Calle y número)")]
        public string? Address { get; set; }

        [Display(Name = "Colonia")]
        public string? Neighborhood { get; set; }

        [Display(Name = "Código Postal")]
        public string? PostalCode { get; set; }

        [Display(Name = "Población")]
        public string? City { get; set; }

        [Display(Name = "Municipio")]
        public string? Municipality { get; set; } = "Hermosillo";

        [Display(Name = "Estado")]
        public string? State { get; set; } = "Sonora";

        [Display(Name = "Número de empleado")]
        public string EmployeeNumber { get; set; }

        [DisplayFormat(DataFormatString = "{0:dd/MM/yyyy}", ApplyFormatInEditMode = true)]
        [Display(Name = "Fecha de ingreso")]
        public DateTime SignUpDate { get; set; }

        [DisplayFormat(DataFormatString = "{0:dd/MM/yyyy}", ApplyFormatInEditMode = true)]
        [Display(Name = "Fecha de nacimiento")]
        public DateTime? Birthday { get; set; }

        [Display(Name = "Estado Civil")]
        public MaritalStatus? MaritalStatus { get; set; }

        [Display(Name = "Departamento")]
        public string? Departament { get; set; }

        [Display(Name = "Tipo de Empleado")]
        public string? TypeEmployee { get; set; }

        [Display(Name = "Sexo")]
        public SexEnum Sex { get; set; }


        [Display(Name = "RFC")]
        public string RFC { get; set; }

        [Display(Name = "CURP")]
        public string CURP { get; set; }

        [Display(Name = "Acepto los términos y condiciones el aviso de privacidad vigente.")]
        public bool TestamentWarning { get; set; }
        [Display(Name = "Estado")]
        public bool? IsVerified { get; set; }

        public bool IsDeleted { get; set; } = false;

        [Display(Name = "Estado de Cita")]
        public bool? IsQuoted { get; set; }
        public List<EconomicDependant> EconomicDependants { get; set; } = new List<EconomicDependant>();
        public List<TesmamentedPeople> TesmamentedPeoples { get; set; } = new List<TesmamentedPeople>();
        public virtual List<FileManager> FilesManager { get; set; }
        public List<Appointment> Appointments { get; set; } = new List<Appointment>();
    }

    public class EconomicDependant 
    {
        public int Id { get; set; }

        public DateTime CreationDate { get; set; } = DateTime.Now;

        [Display(Name = "Nombre")]
        public string Name { get; set; }

        [Display(Name = "Parentesco")]
        public RelationshipED Relationship { get; set; }
        [Display(Name = "CURP")]
        public string? CURP { get; set; }

        [DisplayFormat(DataFormatString = "{0:dd/MM/yyyy}", ApplyFormatInEditMode = true)]
        [Display(Name = "Fecha de nacimiento")]
        public DateTime? BirthDay { get; set; }

        [Display(Name = "Número de empleado")]
        public int EmployeeId { get; set; }
        public string EmployeeNumber { get; set; }

        [Display(Name = "Empleado")]
        public Employee employee { get; set; }
        public virtual List<FileManager> FilesManager { get; set; }
        public bool IsDeleted { get; set; } = false;
    }

    public class TesmamentedPeople
    {
        public int Id { get; set; }
        public DateTime CreationDate { get; set; } = DateTime.Now;
        [Display(Name = "Nombre")]
        public string Name { get; set; }

        [Display(Name = "Parentesco")]
        public RelationshipTP Relationship { get; set; }
        [Display(Name = "CURP")]
        public string CURP { get; set; }

        [Display(Name = "Porcentaje")]
        public int Percentage { get; set; }
        [Display(Name = "Numero de Empleado")]
        public int EmployeeId { get; set; }

        public Employee Employee { get; set; }

        [Display(Name = "Beneficiario principal")]
        public bool isMain { get; set; }
        public virtual List<FileManager> FilesManager { get; set; }
        public bool IsDeleted { get; set; } = false;
    }

    public class Appointment
    {
        public int Id { get; set; }
        [DisplayFormat(DataFormatString = "{0:dd/MM/yyyy}", ApplyFormatInEditMode = true)]
        [Display(Name = "Fecha de creación")]
        public DateTime CreationDate { get; set; } = DateTime.Now;
        [Display(Name = "Fecha de Cita")]
        public DateTime appointmentE { get; set; } = DateTime.Now;

        [Display(Name = "Número de empleado")]
        public int EmployeeId { get; set; }

        [Display(Name = "Empleado")]
        public virtual Employee employee { get; set; }
        public virtual List<LaboratoryDocuments> LaboratoryDocuments { get; set; }
        public bool IsDeleted { get; set; } = false;


    }

    public class LaboratoryDocuments
    {
        public int Id { get; set; }
        [Display(Name = "Nombre del Documento")]
        public string nameDoc { get; set; }
        [Display(Name = "Comentario")]
        public string Comment { get; set; }
        [Display(Name = "Número de Cita")]
        public int AppointmentId { get; set; }
        [Display(Name = "Cita")]
        public Appointment appointment { get; set; }
        [NotMapped]
        [Display(Name = "Archivo")]
        public IFormFile File { get; set; }
    }

    public class EmployeeViewModel
    {
        public Employee Employee { get; set; }
        public string TestamentWarning = Resource.TestamentWarning;

    }

    public class Retired
    {
        public int Id { get; set; }

        [DisplayFormat(DataFormatString = "{0:dd/MM/yyyy}", ApplyFormatInEditMode = true)]
        [Display(Name = "Fecha de captura")]
        public DateTime CreationDate { get; set; } = DateTime.Now;

        [Display(Name = "Número de empleado")]
        public string? EmployeeNumber { get; set; }

        [Display(Name = "Número de Pensión")]
        public string? PensionNumber { get; set; }

        [Display(Name = "Nombre(s)")]
        public string? Name { get; set; }

        [Display(Name = "Apellido Paterno")]
        public string? PLastName { get; set; }

        [Display(Name = "Apellido Materno")]
        public string? MLastName { get; set; }

        [Display(Name = "Monto de la pensión")]
        public double Pension { get; set; }

        [Display(Name = "Compañía")]
        public Companies Company { get; set; }

        [Display(Name = "Puesto")]
        public Jobs Job { get; set; }

        [Display(Name = "Tipo de pensión")]
        public typesPension TypePension { get; set; }

        [Display(Name = "Sexo")]
        public SexEnum Sex { get; set; }

        [Display(Name = "Dirección (Calle y número)")]
        public string Address { get; set; }

        [Display(Name = "Colonia")]
        public string Neighborhood { get; set; }

        [Display(Name = "Código Postal")]
        public string PostalCode { get; set; }

        [Display(Name = "Teléfono particular")]
        public string Tel { get; set; }

        [Display(Name = "Teléfono Celular")]
        public string Cel { get; set; }

        [Display(Name = "Población")]
        public string City { get; set; }

        [Display(Name = "Municipio")]
        public string? Municipality { get; set; } = "Hermosillo";

        [Display(Name = "Estado")]
        public string? State { get; set; } = "Sonora";

        [Display(Name = "Adscripción de procedencia")]
        public AdscripcionEnum? Adscripcion { get; set; } = 0;

        [Display(Name = "Departamento de procedencia")]
        public DepartmentEnum? Departament { get; set; } = 0;

        [Display(Name = "Correo Electrónico")]
        public string? EmailE { get; set; }

        [DisplayFormat(DataFormatString = "{0:dd/MM/yyyy}", ApplyFormatInEditMode = true)]
        [Display(Name = "Fecha de nacimiento")]
        public DateTime? Birthday { get; set; }

        [DisplayFormat(DataFormatString = "{0:dd/MM/yyyy}", ApplyFormatInEditMode = true)]
        [Display(Name = "Fecha de Alta")]
        public DateTime SignUpDate { get; set; }

        [DisplayFormat(DataFormatString = "{0:dd/MM/yyyy}", ApplyFormatInEditMode = true)]
        [Display(Name = "Fecha de Jubilación")]
        public DateTime RetiredDate { get; set; }

        [Display(Name = "Estado Civil")]
        public MaritalStatus? MaritalStatus { get; set; }

        [Display(Name = "RFC")]
        public string RFC { get; set; }

        [Display(Name = "CURP")]
        public string CURP { get; set; }

        [Display(Name = "Estado")]
        public RetiredStatus Status { get; set; }

        public bool IsDeleted { get; set; } = false;
    }

    public class Pensionable
    {
        public int Id { get; set; }

        [DisplayFormat(DataFormatString = "{0:dd/MM/yyyy}", ApplyFormatInEditMode = true)]
        [Display(Name = "Fecha de captura")]
        public DateTime CreationDate { get; set; } = DateTime.Now;

        [Display(Name = "Número de empleado")]
        public string? EmployeeNumber { get; set; }

        [Display(Name = "Número de Pensión")]
        public string? PensionNumber { get; set; }

        [Display(Name = "Nombre(s)")]
        public string? Name { get; set; }

        [Display(Name = "Apellido Paterno")]
        public string? PLastName { get; set; }

        [Display(Name = "Apellido Materno")]
        public string? MLastName { get; set; }

        [Display(Name = "Ingresos")]
        public double Pension { get; set; }

        [Display(Name = "Compañía")]
        public Companies Company { get; set; }

        [Display(Name = "Puesto")]
        public Jobs Job { get; set; }

        [Display(Name = "Tipo de pensión")]
        public typesPension TypePension { get; set; }

        [Display(Name = "Género")]
        public SexEnum Sex { get; set; }

        [Display(Name = "Dirección (Calle y número)")]
        public string Address { get; set; }

        [Display(Name = "Colonia")]
        public string Neighborhood { get; set; }

        [Display(Name = "Código Postal")]
        public string PostalCode { get; set; }

        [Display(Name = "Población")]
        public string City { get; set; }

        [Display(Name = "Municipio")]
        public string? Municipality { get; set; } = "Hermosillo";

        [Display(Name = "Estado")]
        public string? State { get; set; } = "Sonora";

        [Display(Name = "Adscripción de procedencia")]
        public AdscripcionEnum? Adscripcion { get; set; }

        [Display(Name = "Departamento de procedencia")]
        public DepartmentEnum? Departament { get; set; }

        [Display(Name = "Correo Electrónico")]
        public string? EmailE { get; set; }

        [DisplayFormat(DataFormatString = "{0:dd/MM/yyyy}", ApplyFormatInEditMode = true)]
        [Display(Name = "Fecha de nacimiento")]
        public DateTime? Birthday { get; set; }

        [DisplayFormat(DataFormatString = "{0:dd/MM/yyyy}", ApplyFormatInEditMode = true)]
        [Display(Name = "Fecha de Alta")]
        public DateTime SignUpDate { get; set; }

        [DisplayFormat(DataFormatString = "{0:dd/MM/yyyy}", ApplyFormatInEditMode = true)]
        [Display(Name = "Fecha de Pensión")]
        public DateTime RetiredDate { get; set; }

        [Display(Name = "Estado Civil")]
        public MaritalStatus? MaritalStatus { get; set; }

        [Display(Name = "RFC")]
        public string RFC{ get; set; }

        [Display(Name = "CURP")]
        public string CURP { get; set; }

        public bool IsDeleted { get; set; }

        [Display(Name = "Proceso")]
        public StatusPensionable Status { get; set; }

        [Display(Name = "Generación")]
        public Generation? Generation { get; set; }

        [DisplayFormat(DataFormatString = "{0:dd/MM/yyyy}", ApplyFormatInEditMode = true)]
        [Display(Name = "Fecha Estimada de inicio de tramite")]
        public DateTime? ETADate { get; set; }

        [DisplayFormat(DataFormatString = "{0:dd/MM/yyyy}", ApplyFormatInEditMode = true)]
        [Display(Name = "Fecha de ingreso a Isssteson")]
        public DateTime? IssstesonDate { get; set; }

        [DisplayFormat(DataFormatString = "{0:dd/MM/yyyy}", ApplyFormatInEditMode = true)]
        [Display(Name = "Fecha de ingreso a Ayuntamiento")]
        public DateTime? AyuntamientoDate { get; set; }
        [Display(Name = "Sueldo Regulador")]
        public int SueldoRegulador { get; set; }
        [Display(Name = "Servicios especiales")]
        public int ServiciosEspeciales { get; set; }

        [Display(Name = "Teléfono particular")]
        public string Tel { get; set; }

        [Display(Name = "Teléfono Celular")]
        public string Cel { get; set; }

        [NotMapped]
        public List<FilePensionables> FilePensionables { get; set; }
        //public ICollection<FilePensionables> Files { get; set; }
        public virtual List<GenericProject.Models.ControlTable> ControlTable { get; set; }
        // Exclude this property from being mapped to a database column
        [NotMapped]
        public virtual TablePensionablesViewModel TablePensionablesViewModel { get; set; }


    }

    public class DocsExcel
    {
        public int Id { get; set; }

        [DisplayFormat(DataFormatString = "{0:dd/MM/yyyy}", ApplyFormatInEditMode = true)]
        [Display(Name = "Fecha de creación")]
        public DateTime CreationDate { get; set; } = DateTime.Now;
        [Display(Name = "Nombre del Documento")]
        public string FileName { get; set; }    
        [NotMapped]
        [Display(Name = "Archivo")]
        public IFormFile File { get; set; }
    }

    public class ExcelAll
    {
        public int Id { get; set; }
        public string Año { get; set; }
        public string Periodo { get; set; }
        public string NOEMPx { get; set; }
        public string Nombre { get; set; }
        public string ApPaterno { get; set; }
        public string ApMaterno { get; set; }
        public string RFC { get; set; }
        public string CURP { get; set; }
        public string IMSS { get; set; }
        public string ISSSTE { get; set; }
        public string Infonavit { get; set; }
        public string Compañía { get; set; }
        public string Vigencia { get; set; }
        public string Fecha_Alta { get; set; }
        public string Fecha_Baja { get; set; }
        public string Sexo { get; set; }
        public string Fecha_Nac { get; set; }
        public string Fecha_Reingreso { get; set; }
        public string Años_Ant { get; set; }
        public string Art100 { get; set; }
        public string CodigoPuesto { get; set; }
        public string Puesto { get; set; }

        [JsonProperty("Nivel Puesto")]
        public string NivelPuesto { get; set; }
        public string Dependencia { get; set; }
        public string Direccion { get; set; }
        public string Clave_Nodo { get; set; }
        public string Departamento { get; set; }

        [JsonProperty("Centro de Costos")]
        public string CentroDeCostos { get; set; }
        public string FormaPago { get; set; }
        public string Banco { get; set; }

        [JsonProperty("Serv Medico Patron")]
        public string ServMedicoPatron { get; set; }

        [JsonProperty("monto SVida")]
        public string MontoSVida { get; set; }

        [JsonProperty("Aguinaldo Proporcional")]
        public string AguinaldoProporcional { get; set; }
        public string Adscripcion { get; set; }
        public string Horario { get; set; }
        public string Turno { get; set; }
        public string Generacion { get; set; }
        public string Sindicato { get; set; }
        public string Pension { get; set; }

        [JsonProperty("Salario Diario")]
        public string SalarioDiario { get; set; }

        [JsonProperty("Salario Integrado")]
        public string SalarioIntegrado { get; set; }
        public string Tot_Percepciones { get; set; }
        public string Tot_Deducciones { get; set; }
        public string Neto { get; set; }

        [JsonProperty("1-SUELDO")]
        public string _1SUELDO { get; set; }

        [JsonProperty("2-PENSIONADO")]
        public string _2PENSIONADO { get; set; }

        [JsonProperty("3-DELEGADOS")]
        public string _3DELEGADOS { get; set; }

        [JsonProperty("4-COMPENSACION NORMAL")]
        public string _4COMPENSACIONNORMAL { get; set; }

        [JsonProperty("5-COMPENSACION NIVELACION")]
        public string _5COMPENSACIONNIVELACION { get; set; }

        [JsonProperty("6-COMPENSACION ANTIGUEDAD")]
        public string _6COMPENSACIONANTIGUEDAD { get; set; }

        [JsonProperty("7-COMPENSACION POLICIA")]
        public string _7COMPENSACIONPOLICIA { get; set; }

        [JsonProperty("8-SERVICIOS ESPECIALES D10")]
        public string _8SERVICIOSESPECIALESD10 { get; set; }

        [JsonProperty("9-SERVICIOS ESPECIALES TITULARES D10T")]
        public string _9SERVICIOSESPECIALESTITULARESD10T { get; set; }

        [JsonProperty("10-ESTIMULO")]
        public string _10ESTIMULO { get; set; }

        [JsonProperty("11-ESTIMULO AL MANDO")]
        public string _11ESTIMULOALMANDO { get; set; }

        [JsonProperty("17-DEV DE INFONAVIT")]
        public string _17DEVDEINFONAVIT { get; set; }

        [JsonProperty("18-PRIMA VACACIONAL")]
        public string _18PRIMAVACACIONAL { get; set; }

        [JsonProperty("22-TRANSPORTE")]
        public string _22TRANSPORTE { get; set; }

        [JsonProperty("23-PRIMA DE RIESGO")]
        public string _23PRIMADERIESGO { get; set; }

        [JsonProperty("24-BONO DE RESPONSABILIDADES")]
        public string _24BONODERESPONSABILIDADES { get; set; }

        [JsonProperty("50-JUBILADO")]
        public string _50JUBILADO { get; set; }

        [JsonProperty("59-SUBSIDIO AL EMPLEO INFORMATIVO")]
        public string _59SUBSIDIOALEMPLEOINFORMATIVO { get; set; }

        [JsonProperty("60-COMPENSACION")]
        public string _60COMPENSACION { get; set; }

        [JsonProperty("70-SUELDO TEMPORALES SIN SERV MEDICO")]
        public string _70SUELDOTEMPORALESSINSERVMEDICO { get; set; }

        [JsonProperty("101-ISR SUELDO")]
        public string _101ISRSUELDO { get; set; }

        [JsonProperty("102-SERVICIO MEDICO")]
        public string _102SERVICIOMEDICO { get; set; }

        [JsonProperty("104-FONDO DE PENSIONES")]
        public string _104FONDODEPENSIONES { get; set; }

        [JsonProperty("107-PREST CORTO PLAZO")]
        public string _107PRESTCORTOPLAZO { get; set; }

        [JsonProperty("109-PREST HIPOTECARIO")]
        public string _109PRESTHIPOTECARIO { get; set; }

        [JsonProperty("110-PREST SINDICAL")]
        public string _110PRESTSINDICAL { get; set; }

        [JsonProperty("111-DEUDORES DIVERSOS")]
        public string _111DEUDORESDIVERSOS { get; set; }

        [JsonProperty("115-FONACOT")]
        public string _115FONACOT { get; set; }

        [JsonProperty("116-SERV MEDICO A PADRES")]
        public string _116SERVMEDICOAPADRES { get; set; }

        [JsonProperty("121-CUOTA SINDICATO 1")]
        public string _121CUOTASINDICATO1 { get; set; }

        [JsonProperty("122-DESCTO JUICIO MERCANTIL")]
        public string _122DESCTOJUICIOMERCANTIL { get; set; }

        [JsonProperty("124-PENSION ALIMENTICIA 1")]
        public string _124PENSIONALIMENTICIA1 { get; set; }

        [JsonProperty("126-PENSION ALIMENTICIA 2")]
        public string _126PENSIONALIMENTICIA2 { get; set; }

        [JsonProperty("127-PENSION ALIMENTICIA 3")]
        public string _127PENSIONALIMENTICIA3 { get; set; }

        [JsonProperty("128-PENSION ALIMENTICIA 4")]
        public string _128PENSIONALIMENTICIA4 { get; set; }

        [JsonProperty("130-RETENCION CREDITO INFONAVIT")]
        public string _130RETENCIONCREDITOINFONAVIT { get; set; }

        [JsonProperty("132-VIVIENDA PROMOTORA")]
        public string _132VIVIENDAPROMOTORA { get; set; }

        [JsonProperty("133-FONDO SINDICATO 1")]
        public string _133FONDOSINDICATO1 { get; set; }

        [JsonProperty("138-FONDO FUNERARIO SAITAHS")]
        public string _138FONDOFUNERARIOSAITAHS { get; set; }

        [JsonProperty("140-SANCION POR PENSION ALIMENTICIA")]
        public string _140SANCIONPORPENSIONALIMENTICIA { get; set; }

        [JsonProperty("141-AJUSTE SUBSIDIO")]
        public string _141AJUSTESUBSIDIO { get; set; }

        [JsonProperty("144-PRESTAMO SINDICAL SAITAHS")]
        public string _144PRESTAMOSINDICALSAITAHS { get; set; }

        [JsonProperty("146-CUOTA SINDICATO 2")]
        public string _146CUOTASINDICATO2 { get; set; }

        [JsonProperty("147-CUOTA SINDICATO 3")]
        public string _147CUOTASINDICATO3 { get; set; }

        [JsonProperty("148-FONDO SINDICATO 2")]
        public string _148FONDOSINDICATO2 { get; set; }

        [JsonProperty("151-PREST SINDICATO 3")]
        public string _151PRESTSINDICATO3 { get; set; }

        [JsonProperty("155-GASTOS INFRAESTRUCTURA")]
        public string _155GASTOSINFRAESTRUCTURA { get; set; }

        [JsonProperty("156-PRESTAMO CORTO PLAZO")]
        public string _156PRESTAMOCORTOPLAZO { get; set; }

        [JsonProperty("158-CUOTA SINDICATO 4")]
        public string _158CUOTASINDICATO4 { get; set; }

        [JsonProperty("4001-SUELDO R3")]
        public string _4001SUELDOR3 { get; set; }

        [JsonProperty("4004-COMPENSACION NORMAL R3")]
        public string _4004COMPENSACIONNORMALR3 { get; set; }

        [JsonProperty("4005-COMPENSACION NIVELACION R3")]
        public string _4005COMPENSACIONNIVELACIONR3 { get; set; }

        [JsonProperty("4008-SERVICIOS ESPECIALES D10 R3")]
        public string _4008SERVICIOSESPECIALESD10R3 { get; set; }

        [JsonProperty("4009-SERVICIOS ESPECIALES TITULARES D10T R3")]
        public string _4009SERVICIOSESPECIALESTITULARESD10TR3 { get; set; }

        [JsonProperty("4010-ESTIMULO R3")]
        public string _4010ESTIMULOR3 { get; set; }

        [JsonProperty("4011-ESTIMULO AL MANDO R3")]
        public string _4011ESTIMULOALMANDOR3 { get; set; }

        [JsonProperty("4027-AYUDA ENERGIA ELECTRICA")]
        public string _4027AYUDAENERGIAELECTRICA { get; set; }

        [JsonProperty("4097-SUBSIDIO ISR")]
        public string _4097SUBSIDIOISR { get; set; }

        [JsonProperty("4101-ISR R3")]
        public string _4101ISRR3 { get; set; }

        [JsonProperty("4197-AJUSTE SUBSIDIO AL EMPLEADO")]
        public string _4197AJUSTESUBSIDIOALEMPLEADO { get; set; }
        public string PER { get; set; }
        public string DED { get; set; }
        public string NETO1 { get; set; }
        public string DIF { get; set; }
        public string PER1 { get; set; }
        public string DED1 { get; set; }
        public string NETO2 { get; set; }
        public string DIF1 { get; set; }
        public string Column1 { get; set; }
    }

    public class FileManager
    {
        public int Id { get; set; }
        [Display(Name = "Tipo de documento")]
        public DocType DocType { get; set; }

        public string Alias { get; set; }
        [Display(Name = "Nombre del Documento")]
        public string FileName { get; set; }
        [Display(Name = "Id de Empleado")]
        public int? EmployeeId { get; set; }
        [Display(Name = "Número de Empleado")]
        public int? EmployeeNumber { get; set; }
        [Display(Name = "Empleado")]
        public virtual Employee Employee { get; set; }
        public int? EconomicDependantId { get; set; }
        [Display(Name = "Dependiente Económico")]
        public virtual EconomicDependant EconomicDependant { get; set; }
        [Display(Name = "Persona Testamentada")]
        public int? TesmamentedPeopleId { get; set; }
        [Display(Name = "Persona Testamentada")]
        public virtual TesmamentedPeople TesmamentedPeople { get; set; }

        [NotMapped]
        [Display(Name = "Archivo")]
        public IFormFile File { get; set; }
        public bool IsDeleted { get; set; } = false;
    }

    public enum TypeResponsible
    {
        [Display(Name = "Complementaria")]
        Complementaria,
        [Display(Name = "Directa ayuntamiento")]
        Ayuntamiento,
        [Display(Name = "Directa ISSSTESON")]
        Isssteson,
        [Display(Name = "Compartida")]
        Compartida
    }

    public enum RelationshipED
    {

        Hijo,
        Esposo,
        Conyuge,
    }

    public enum RelationshipTP
    {

        Hijo,
        Esposo,
        Padre,
        Madre,
        Otro,
    }

    public enum SexEnum
    {
        Masculino,
        Femenino,
        NoBinario,
        Otro


    }

    public enum RetiredStatus
    {
        [Display(Name = "Ninguno")]
        None = 0,
        [Display(Name = "Vivo")]
        Alive = 1,              //VIVO             -- #cccccc
        [Display(Name = "No Identificado")]
        Undefined = 2,          //NO IDENTIFICADO             -- #ffdf00
        [Display(Name = "Fallecido")]
        Deceased = 3,           //Fallecido    -- #87e66c
    }

    public enum StatusPensionable
    {
        [Display(Name = "Paso 1: Pensiones")]
        Step1 = 0,
        [Display(Name = "Paso 2: Trabajadora Social")]
        Step2 = 1,
        [Display(Name = "Paso 3: Pensiones")]
        Step3 = 2,
        [Display(Name = "Paso 4: ISSSTESON")]
        Step4 = 3,
        [Display(Name = "Paso 5: JUR DRH / Actuarios")]
        Step5 = 4,
        [Display(Name = "Paso 6: Pensiones")]
        Step6 = 5,
        [Display(Name = "Paso 7: Pensiones/JDRH")]
        Step7 = 6,
        [Display(Name = "Paso 8: Pensiones")]
        Step8 = 7,
        [Display(Name = "Paso 9: Archivo")]
        Step9 = 8,
    }

    public enum MaritalStatus
    {
        Casado,
        Soltero,
        Concubinato,
    }

    public enum Companies
    {
        [Display(Name = "Jubilados y Pensionados")]
        JubyPen,
        [Display(Name = "Beneficiados por Pensión")]
        BenxPension,
        [Display(Name = "Invalidez Temporal")]
        InvTemp,

    }

    public enum Jobs
    {
        [Display(Name = "Jubilado Titular (I)")]
        JUBILADOTITULAR,
        [Display(Name = "Pensión por ascendencia (I)")]
        PensionxAs,
        [Display(Name = "Pensión por Orfandad 25-29 años (I)")]
        PensionXOrfa,
        [Display(Name = "Pensión por orfandad de jubilado (I)")]
        PensionxOrfa2,
        [Display(Name = "Pensión por Orfandad menos de 15 años (I)")]
        PensionxOrfa3,
        [Display(Name = "Pensionado menos de 15 años (I)")]
        Pensionado15,
        [Display(Name = "Pensionado titular 15-19 años (I)")]
        Pensionado1519,
        [Display(Name = "Pensionado titular 20-24 años (I)")]
        Pensionado2024,
        [Display(Name = "Pensionado titular 25-29 años (I)")]
        Pensionado2529,
        [Display(Name = "Viuda de Jubilado (I)")]
        Viuda1,
        [Display(Name = "Viuda de pensionado menos 15 años(I)")]
        Viuda2,
        [Display(Name = "Viuda de pensionado 15-19 años(I)")]
        Viuda3,
        [Display(Name = "Viuda de pensionado 20-24 años(I)")]
        Viuda4,
        [Display(Name = "Viuda de pensión 25-29 años(I)")]
        Viuda5,
    }

    public enum typesPension
    {
        Complementaria,
        Compartidas,
        Isssteson,
        Ayuntamiento
    }

    public enum classPension
    {
        [Display(Name = "Vejez")] Vejez,
        [Display(Name = "Jubilación")] Jubilacion,
        [Display(Name = "Cesantía en edad avanzada")] Cesantia,
        [Display(Name = "Invalidez temporal")] Temporal,
        [Display(Name = "Invalidez permanente")] Pemanente,
        [Display(Name = "Invalidez")] Invalidez,

    }

    public enum DocType
    {
        [Display(Name = "Acta de nacimiento")]
        ActaDeNacimiento,
        [Display(Name = "Comprobante de domicilio")]
        ComprobanteDomicilio,
        [Display(Name = "Identificación")]
        Identificacion,
        [Display(Name = "CURP")]
        CURP,
        [Display(Name = "Acta de matrimonio o concubinato")]
        ActaMatrimonio,
        [Display(Name = "Constancia de estudios")]
        ConstanciaEstudios,
        [Display(Name = "Carta de Adhesión al Sistema")]
        CartaSistema,
        [Display(Name = "Fotografía")]
        Fotografia,
    }

    public enum AsuntosLaborales
    {
        [Display(Name = "Porcentaje")]
        Porcentaje,
        [Display(Name = "No Aplica")]
        NoAplica
    }
    public enum Generation
    {
        [Display(Name = "Futura")] Futura,
        [Display(Name = "Actual")] Actual,
    }
    public enum AdscripcionEnum
    {
        [Display(Name = "Direccion de operacion y forestacion")] Adsc,
        [Display(Name = "Direccion de inspeccion y vigilancia")] Adsc1,
        [Display(Name = "Centro alerta")] Adsc2,
        [Display(Name = "Direccion de seguridad publica")] Adsc3,
        [Display(Name = "Direccion  recoleccion de basura")] Adsc4,
        [Display(Name = "Despacho del director")] Adsc5,
        [Display(Name = "Direccion de obras publicas")] Adsc6,
        [Display(Name = "Direccion de panteones")] Adsc7,
        [Display(Name = "Proyectos especiales")] Adsc8,
        [Display(Name = "Despacho del secretario")] Adsc9,
        [Display(Name = "Direccion del deporte")] Adsc10,
        [Display(Name = "Direccion de ingresos")] Adsc11,
        [Display(Name = "Direccion administrativa")] Adsc12,
        [Display(Name = "Direccion de barrido de calles")] Adsc13,
        [Display(Name = "Direccion del departamento de bomberos")] Adsc14,
        [Display(Name = "Direccion de bienes y servicios")] Adsc15,
        [Display(Name = "Despacho del jefe de policia y transito")] Adsc16,
        [Display(Name = "Direccion adjunta de la tesoreria")] Adsc17,
        [Display(Name = "Dir. De servicios de gobierno")] Adsc18,
        [Display(Name = "Direccion de transito")] Adsc19,
        [Display(Name = "Direccion de recursos humanos")] Adsc20,
        [Display(Name = "Direccion de egresos")] Adsc21,
        [Display(Name = "Direccion de talleres")] Adsc22,
        [Display(Name = "Direccion de catastro")] Adsc23,
        [Display(Name = "Direccion de auditoria gubernamental")] Adsc24,
        [Display(Name = "Direccion de bienes del dominio privado")] Adsc25,
        [Display(Name = "Direccion de planeacion y control urbano")] Adsc26,
        [Display(Name = "Direccion de normatividad ambiental")] Adsc27,
        [Display(Name = "Coordinacion administrativa")] Adsc28,
        [Display(Name = "Despacho del contralor")] Adsc29,
        [Display(Name = "Direccion de imagen urbana")] Adsc30,
        [Display(Name = "Instituto municipal de proteccion y bienestar animal")] Adsc31,
        [Display(Name = "Direccion de accion social")] Adsc32,
        [Display(Name = "Direccion de atencion ciudadana")] Adsc33,
        [Display(Name = "Direccion de informatica")] Adsc34,
        [Display(Name = "Despacho del instituto de cultura")] Adsc35,
        [Display(Name = "Despacho del tesorero municipal")] Adsc36,
        [Display(Name = "Unidad municipal de desarrollo rural")] Adsc37,
        [Display(Name = "Coordinacion sustanciadora y resolutora")] Adsc38,
        [Display(Name = "Despacho del presidente mpal")] Adsc39,
        [Display(Name = "Despacho del comisario")] Adsc40,
        [Display(Name = "Dir. De informacion y medios de comunicacion")] Adsc41,
        [Display(Name = "Instituto hermosillense de la juventud")] Adsc42,
        [Display(Name = "Direccion de control de obras publicas")] Adsc43,
        [Display(Name = "Unidad de transparencia")] Adsc44,
        [Display(Name = "Inspeccion")] Adsc45,
        [Display(Name = "Coordinacion general de beneficios")] Adsc46,
        [Display(Name = "Direccion de vinculacion inst. Y situacion patrimonial")] Adsc47,
        [Display(Name = "Despacho de atencion a la mujer")] Adsc48,
        [Display(Name = "H. Cabildo")] Adsc49,
        [Display(Name = "Direccion de asuntos internos")] Adsc50,
        [Display(Name = "Unidad municipal de proteccion civil")] Adsc51,
        [Display(Name = "Direccion de coordinacion investigadora")] Adsc52,
        [Display(Name = "Direccion de desarrollo turistico")] Adsc53,
        [Display(Name = "Direccion juridica")] Adsc54,
        [Display(Name = "Secretaria particular")] Adsc55,
        [Display(Name = "Direccion de fomento al turismo")] Adsc56,
        [Display(Name = "Direccion de evaluacion al desempeño")] Adsc57,
        [Display(Name = "Procuraduria municipal y del espacio publico")] Adsc58,
        [Display(Name = " Sindicatura del Ayuntamiento")] Adsc59,
        [Display(Name = " Jefatura de Oficina de la Presidencia Municipal")] Adsc60,
        [Display(Name = " Órgano de Control y Evaluación Gubernamental ")] Adsc61,
        [Display(Name = " Dirección General de Comunicación Social y Transparencia")] Adsc62,
        [Display(Name = " Secretaría del Ayuntamiento")] Adsc63,
        [Display(Name = " Tesorería Municipal")] Adsc64,
        [Display(Name = " Jefatura de Policía Preventiva y Tránsito Municipal")] Adsc65,
        [Display(Name = " Coordinación General de Infraestructura, Desarrollo Urbano y Ecología")] Adsc66,
        [Display(Name = " Dirección General de Servicios Públicos Municipales")] Adsc67,
        [Display(Name = " Oficialía Mayor")] Adsc68,
        [Display(Name = " Dirección General de Participación Ciudadana")] Adsc69,
        [Display(Name = "Consejo Municipal de Concertación de la Obra Pública")] Adsc70,
        [Display(Name = "Instituto Municipal del Deporte y la Juventud")] Adsc71,
        [Display(Name = "D.I.F. Hermosillo")] Adsc72,
        [Display(Name = "Coordinación General Jurídica")] Adsc73,
        [Display(Name = " Comisaría de Bahía de Kino")] Adsc74,
        [Display(Name = " Comisaría del Poblado Miguel Alemán")] Adsc75,
        [Display(Name = "Instituto Municipal de Planeación Urbana")] Adsc76,
        [Display(Name = "Instituto Municipal de Arte y Cultura")] Adsc77,
        [Display(Name = "Agencia de Fomento Económico")] Adsc78,
        [Display(Name = " Dirección General de Atención a la Mujer")] Adsc79,
        [Display(Name = " Dirección General de Atención Ciudadana")] Adsc80
    }

    public enum DepartmentEnum
    {
        [Display(Name = "Parques y jardines")] dept,
        [Display(Name = "Cultura de la legalidad")] dept1,
        [Display(Name = "Recoleccion de basura")] dept3,
        [Display(Name = "Semaforizacion y señalizacion")] dept5,
        [Display(Name = "Panteones")] dept6,
        [Display(Name = "Asuntos de la sria. Del ayuntamiento")] dept10,
        [Display(Name = "Planeacion")] dept12,
        [Display(Name = "Bomberos")] dept14,
        [Display(Name = "Administracion de los rec. Humanos")] dept19,
        [Display(Name = "Auditoria")] dept20,
        [Display(Name = "Planeacion urbana")] dept26,
        [Display(Name = "Bahia de kino")] dept30,
        [Display(Name = "Resolucion de investigaciones")] dept35,
        [Display(Name = "H. Ayuntamiento")] dept43,
        [Display(Name = "Proteccion civil")] dept44,
        [Display(Name = "Fomento para los emprendedores y pymes")] dept46,
        [Display(Name = "Regularización de la Tenencia de la Tierra")] dept47,
        [Display(Name = "Asuntos del C. Presidente")] dept48,
        [Display(Name = "Procesos Administrativos")] dept49,
        [Display(Name = "Investigación de Responsabilidades")] dept51,
        [Display(Name = "Registro de Bienes Patrimoniales de Funcionarios e Investigación de Responsabilidades")] dept52,
        [Display(Name = "Conducción y Ejecución de la Política de Comunicación Social")] dept54,
        [Display(Name = "Transparencia")] dept55,
        [Display(Name = "Cultura de la Legalidad")] dept56,
        [Display(Name = "Salud")] dept57,
        [Display(Name = "Comunidad Rural")] dept60,
        [Display(Name = "Contabilidad, Patrimonio y Rendición de Cuentas")] dept61,
        [Display(Name = "Planeación")] dept62,
        [Display(Name = "Ejecución Fiscal")] dept63,
        [Display(Name = "Cobranza")] dept64,
        [Display(Name = "Administración de la Política de Egresos del Municipio")] dept65,
        [Display(Name = "Definición y Conducción de la Política de Planeación, Programación y Presupuestación del Gasto Publico")] dept66,
        [Display(Name = "Catastro")] dept67,
        [Display(Name = "Seguridad Vial")] dept68,
        [Display(Name = "Vigilancia")] dept69,
        [Display(Name = "Miguel Alemán")] dept71,
        [Display(Name = "Estudios y Proyectos")] dept73,
        [Display(Name = "Construcción y Conservación de Calles y Avenidas")] dept75,
        [Display(Name = "Construcción y Rehabilitación de Infraestructura")] dept76,
        [Display(Name = "Ecología")] dept77,
        [Display(Name = "Limpia y Barrido de Calles y Avenidas")] dept78,
        [Display(Name = "Administración")] dept82,
        [Display(Name = "Corralones del Ayuntamiento de Hermosillo (Administración)")] dept83,
        [Display(Name = "Administración de los Recursos Humanos")] dept84,
        [Display(Name = "Coordinación Interinstitucional y Vinculación con Sectores")] dept85,
        [Display(Name = "Combate a la Desigualdad")] dept86,
        [Display(Name = "Impulso y Apoyo a la Juventud")] dept87,
        [Display(Name = "Impulso al Deporte y Recreación")] dept88,
        [Display(Name = "Integración Social y Familiar")] dept89,
        [Display(Name = "Atención de Asuntos Gubernamentales y de Apoyo Técnico")] dept90,
        [Display(Name = "Administración del Uso del Suelo")] dept91,
        [Display(Name = "Movilidad y Conectividad Urbana")] dept92,
        [Display(Name = "Preservación, Impulso y Difusión de la Cultura")] dept93,
        [Display(Name = "Cultura Incluyente")] dept94,
        [Display(Name = "Fomento Para los Emprendedores y Pymes")] dept95,
        [Display(Name = "Apoyo a la Mujer")] dept96,
        [Display(Name = "Atención y Participación Ciudadana")] dept97,
        [Display(Name = "Médico Legista")] dept98,
        [Display(Name = "Jueces Calificadores")] dept99

    }
}
