﻿using GenericProject.Models;
using System;
using System.Collections.Generic;
using System.Linq;


namespace GenericProject.DTOs
{
    public class EmployeeCreate
    {
        public int EmployeeId { get; set; }

        
    }
}