﻿using GenericProject.Models;
using System;
using System.Collections.Generic;
using System.Linq;


namespace GenericProject.DTOs
{
    public class AppointmentOutput
    {
        public int EmployeeId { get; set; }

        public List<Appointment> Appointments { get; set; }

    }
}
