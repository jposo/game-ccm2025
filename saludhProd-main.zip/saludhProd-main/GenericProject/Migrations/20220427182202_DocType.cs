﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace GenericProject.Migrations
{
    public partial class DocType : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "TypeDoc",
                table: "FileManager");

            migrationBuilder.AddColumn<int>(
                name: "DocType",
                table: "FileManager",
                nullable: false,
                defaultValue: 0);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "DocType",
                table: "FileManager");

            migrationBuilder.AddColumn<int>(
                name: "TypeDoc",
                table: "FileManager",
                type: "int",
                nullable: false,
                defaultValue: 0);
        }
    }
}
