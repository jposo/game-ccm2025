﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace GenericProject.Migrations
{
    public partial class nuevoscampos : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<int>(
                name: "TypeDoc",
                table: "FileManager",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AddColumn<int>(
                name: "Cel",
                table: "Employee",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AddColumn<string>(
                name: "EmailE",
                table: "Employee",
                nullable: true);

            migrationBuilder.AddColumn<int>(
                name: "Tel",
                table: "Employee",
                nullable: false,
                defaultValue: 0);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "TypeDoc",
                table: "FileManager");

            migrationBuilder.DropColumn(
                name: "Cel",
                table: "Employee");

            migrationBuilder.DropColumn(
                name: "EmailE",
                table: "Employee");

            migrationBuilder.DropColumn(
                name: "Tel",
                table: "Employee");
        }
    }
}
