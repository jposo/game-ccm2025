﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace GenericProject.Migrations
{
    public partial class LabDocs : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<int>(
                name: "EmployeeId",
                table: "LaboratoryDocuments",
                nullable: true);

            migrationBuilder.CreateIndex(
                name: "IX_LaboratoryDocuments_EmployeeId",
                table: "LaboratoryDocuments",
                column: "EmployeeId");

            migrationBuilder.AddForeignKey(
                name: "FK_LaboratoryDocuments_Employee_EmployeeId",
                table: "LaboratoryDocuments",
                column: "EmployeeId",
                principalTable: "Employee",
                principalColumn: "Id",
                onDelete: ReferentialAction.Restrict);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_LaboratoryDocuments_Employee_EmployeeId",
                table: "LaboratoryDocuments");

            migrationBuilder.DropIndex(
                name: "IX_LaboratoryDocuments_EmployeeId",
                table: "LaboratoryDocuments");

            migrationBuilder.DropColumn(
                name: "EmployeeId",
                table: "LaboratoryDocuments");
        }
    }
}
