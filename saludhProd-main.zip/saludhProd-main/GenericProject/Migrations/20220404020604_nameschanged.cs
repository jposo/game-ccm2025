﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace GenericProject.Migrations
{
    public partial class nameschanged : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "BeneficiaryId",
                table: "FileManager");

            migrationBuilder.DropColumn(
                name: "TestamentId",
                table: "FileManager");

            migrationBuilder.AddColumn<int>(
                name: "EconomicDependantId",
                table: "FileManager",
                nullable: true);

            migrationBuilder.AddColumn<int>(
                name: "TesmamentedPeopleId",
                table: "FileManager",
                nullable: true);

            migrationBuilder.CreateIndex(
                name: "IX_FileManager_EconomicDependantId",
                table: "FileManager",
                column: "EconomicDependantId");

            migrationBuilder.CreateIndex(
                name: "IX_FileManager_EmployeeId",
                table: "FileManager",
                column: "EmployeeId");

            migrationBuilder.CreateIndex(
                name: "IX_FileManager_TesmamentedPeopleId",
                table: "FileManager",
                column: "TesmamentedPeopleId");

            migrationBuilder.AddForeignKey(
                name: "FK_FileManager_EconomicDependant_EconomicDependantId",
                table: "FileManager",
                column: "EconomicDependantId",
                principalTable: "EconomicDependant",
                principalColumn: "Id",
                onDelete: ReferentialAction.Restrict);

            migrationBuilder.AddForeignKey(
                name: "FK_FileManager_Employee_EmployeeId",
                table: "FileManager",
                column: "EmployeeId",
                principalTable: "Employee",
                principalColumn: "Id",
                onDelete: ReferentialAction.Restrict);

            migrationBuilder.AddForeignKey(
                name: "FK_FileManager_TesmamentedPeople_TesmamentedPeopleId",
                table: "FileManager",
                column: "TesmamentedPeopleId",
                principalTable: "TesmamentedPeople",
                principalColumn: "Id",
                onDelete: ReferentialAction.Restrict);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_FileManager_EconomicDependant_EconomicDependantId",
                table: "FileManager");

            migrationBuilder.DropForeignKey(
                name: "FK_FileManager_Employee_EmployeeId",
                table: "FileManager");

            migrationBuilder.DropForeignKey(
                name: "FK_FileManager_TesmamentedPeople_TesmamentedPeopleId",
                table: "FileManager");

            migrationBuilder.DropIndex(
                name: "IX_FileManager_EconomicDependantId",
                table: "FileManager");

            migrationBuilder.DropIndex(
                name: "IX_FileManager_EmployeeId",
                table: "FileManager");

            migrationBuilder.DropIndex(
                name: "IX_FileManager_TesmamentedPeopleId",
                table: "FileManager");

            migrationBuilder.DropColumn(
                name: "EconomicDependantId",
                table: "FileManager");

            migrationBuilder.DropColumn(
                name: "TesmamentedPeopleId",
                table: "FileManager");

            migrationBuilder.AddColumn<int>(
                name: "BeneficiaryId",
                table: "FileManager",
                type: "int",
                nullable: true);

            migrationBuilder.AddColumn<int>(
                name: "TestamentId",
                table: "FileManager",
                type: "int",
                nullable: true);
        }
    }
}
