﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

namespace GenericProject.Migrations
{
    public partial class TablasNew : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Retired",
                columns: table => new
                {
                    Id = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    CreationDate = table.Column<DateTime>(nullable: false),
                    EmployeeNumber = table.Column<string>(nullable: true),
                    PensionNumber = table.Column<string>(nullable: true),
                    Name = table.Column<string>(nullable: true),
                    PLastName = table.Column<string>(nullable: true),
                    MLastName = table.Column<string>(nullable: true),
                    Pension = table.Column<double>(nullable: false),
                    Company = table.Column<int>(nullable: false),
                    Job = table.Column<int>(nullable: false),
                    TypePension = table.Column<int>(nullable: false),
                    Sex = table.Column<int>(nullable: false),
                    Address = table.Column<string>(nullable: true),
                    Neighborhood = table.Column<string>(nullable: true),
                    PostalCode = table.Column<string>(nullable: true),
                    Tel = table.Column<int>(nullable: false),
                    Cel = table.Column<int>(nullable: false),
                    City = table.Column<string>(nullable: true),
                    Municipality = table.Column<string>(nullable: true),
                    State = table.Column<string>(nullable: true),
                    Adscripcion = table.Column<string>(nullable: true),
                    Departament = table.Column<string>(nullable: true),
                    EmailE = table.Column<string>(nullable: true),
                    Birthday = table.Column<DateTime>(nullable: true),
                    SignUpDate = table.Column<DateTime>(nullable: false),
                    RetiredDate = table.Column<DateTime>(nullable: false),
                    MaritalStatus = table.Column<int>(nullable: true),
                    RFC = table.Column<string>(nullable: true),
                    CURP = table.Column<string>(nullable: true),
                    Status = table.Column<int>(nullable: false),
                    IsDeleted = table.Column<bool>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Retired", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "ControlTable",
                columns: table => new
                {
                    Id = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Step = table.Column<int>(nullable: false),
                    Name = table.Column<string>(nullable: true),
                    PensionableId = table.Column<int>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_ControlTable", x => x.Id);
                    table.ForeignKey(
                        name: "FK_ControlTable_Pensionable_PensionableId",
                        column: x => x.PensionableId,
                        principalTable: "Pensionable",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "FilePensionables",
                columns: table => new
                {
                    Id = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    EmployeeId = table.Column<int>(nullable: false),
                    NameDoc = table.Column<string>(nullable: true),
                    Info = table.Column<string>(nullable: true),
                    IsFile = table.Column<bool>(nullable: false),
                    Step = table.Column<int>(nullable: false),
                    IsDeleted = table.Column<bool>(nullable: false),
                    PensionableId = table.Column<int>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_FilePensionables", x => x.Id);
                    table.ForeignKey(
                        name: "FK_FilePensionables_Pensionable_PensionableId",
                        column: x => x.PensionableId,
                        principalTable: "Pensionable",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "FilesStep1",
                columns: table => new
                {
                    Id = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    EmployeeId = table.Column<int>(nullable: true),
                    EmployeeNumber = table.Column<string>(nullable: true),
                    PensionableId = table.Column<int>(nullable: true),
                    ClassPension = table.Column<string>(nullable: true),
                    FileFichaTecnica = table.Column<string>(nullable: true),
                    FileCartaAlcalde = table.Column<string>(nullable: true),
                    FileFormatoIngreso = table.Column<string>(nullable: true),
                    FileEstatusGenerales = table.Column<string>(nullable: true),
                    FileSolicitudIsssteson = table.Column<string>(nullable: true),
                    FileActaNacimiento = table.Column<string>(nullable: true),
                    FileHojaServicio = table.Column<string>(nullable: true),
                    FileHojaAportacion = table.Column<string>(nullable: true),
                    FileFoto = table.Column<string>(nullable: true),
                    FileCURP = table.Column<string>(nullable: true),
                    FileINE = table.Column<string>(nullable: true),
                    FileTalon = table.Column<string>(nullable: true),
                    FileRFC = table.Column<string>(nullable: true),
                    FileCartaCompromiso = table.Column<string>(nullable: true),
                    FileHojaAyuntamiento = table.Column<string>(nullable: true),
                    IsDeleted = table.Column<bool>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_FilesStep1", x => x.Id);
                    table.ForeignKey(
                        name: "FK_FilesStep1_Pensionable_PensionableId",
                        column: x => x.PensionableId,
                        principalTable: "Pensionable",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "FilesStep2",
                columns: table => new
                {
                    Id = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    EmployeeId = table.Column<int>(nullable: true),
                    FileFichaPermiso = table.Column<string>(nullable: true),
                    FileIngresoPermiso = table.Column<string>(nullable: true),
                    SyndicateNumber = table.Column<int>(nullable: false),
                    Responsible = table.Column<int>(nullable: false),
                    DateRetired = table.Column<DateTime>(nullable: true),
                    IsDeleted = table.Column<bool>(nullable: false),
                    PensionableId = table.Column<int>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_FilesStep2", x => x.Id);
                    table.ForeignKey(
                        name: "FK_FilesStep2_Pensionable_PensionableId",
                        column: x => x.PensionableId,
                        principalTable: "Pensionable",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateIndex(
                name: "IX_ControlTable_PensionableId",
                table: "ControlTable",
                column: "PensionableId");

            migrationBuilder.CreateIndex(
                name: "IX_FilePensionables_PensionableId",
                table: "FilePensionables",
                column: "PensionableId");

            migrationBuilder.CreateIndex(
                name: "IX_FilesStep1_PensionableId",
                table: "FilesStep1",
                column: "PensionableId");

            migrationBuilder.CreateIndex(
                name: "IX_FilesStep2_PensionableId",
                table: "FilesStep2",
                column: "PensionableId");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "ControlTable");

            migrationBuilder.DropTable(
                name: "FilePensionables");

            migrationBuilder.DropTable(
                name: "FilesStep1");

            migrationBuilder.DropTable(
                name: "FilesStep2");

            migrationBuilder.DropTable(
                name: "Retired");

            migrationBuilder.DropTable(
                name: "Pensionable");
        }
    }
}
