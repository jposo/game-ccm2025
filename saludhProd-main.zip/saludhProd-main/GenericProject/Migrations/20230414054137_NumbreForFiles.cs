﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace GenericProject.Migrations
{
    public partial class NumbreForFiles : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "Number",
                table: "ControlTable");

            migrationBuilder.AddColumn<int>(
                name: "Number",
                table: "FilePensionables",
                nullable: false,
                defaultValue: 0);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "Number",
                table: "FilePensionables");

            migrationBuilder.AddColumn<int>(
                name: "Number",
                table: "ControlTable",
                type: "int",
                nullable: false,
                defaultValue: 0);
        }
    }
}
