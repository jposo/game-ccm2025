﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace GenericProject.Migrations
{
    public partial class Atributoparastep1 : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_FilesStep2_Pensionable_PensionableId",
                table: "FilesStep2");

            migrationBuilder.DropIndex(
                name: "IX_FilesStep2_PensionableId",
                table: "FilesStep2");

            migrationBuilder.DropColumn(
                name: "PensionableId",
                table: "FilesStep2");

            migrationBuilder.AddColumn<bool>(
                name: "NecesaryStep1",
                table: "ControlTable",
                nullable: false,
                defaultValue: false);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "NecesaryStep1",
                table: "ControlTable");

            migrationBuilder.AddColumn<int>(
                name: "PensionableId",
                table: "FilesStep2",
                type: "int",
                nullable: true);

            migrationBuilder.CreateIndex(
                name: "IX_FilesStep2_PensionableId",
                table: "FilesStep2",
                column: "PensionableId");

            migrationBuilder.AddForeignKey(
                name: "FK_FilesStep2_Pensionable_PensionableId",
                table: "FilesStep2",
                column: "PensionableId",
                principalTable: "Pensionable",
                principalColumn: "Id",
                onDelete: ReferentialAction.Restrict);
        }
    }
}
