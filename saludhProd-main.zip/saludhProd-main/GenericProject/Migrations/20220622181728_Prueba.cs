﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace GenericProject.Migrations
{
    public partial class Prueba : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<string>(
                name: "CURP",
                table: "TesmamentedPeople",
                nullable: true);

            migrationBuilder.AddColumn<int>(
                name: "Departament",
                table: "Employee",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AddColumn<int>(
                name: "TypeEmployee",
                table: "Employee",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AddColumn<string>(
                name: "CURP",
                table: "EconomicDependant",
                nullable: true);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "CURP",
                table: "TesmamentedPeople");

            migrationBuilder.DropColumn(
                name: "Departament",
                table: "Employee");

            migrationBuilder.DropColumn(
                name: "TypeEmployee",
                table: "Employee");

            migrationBuilder.DropColumn(
                name: "CURP",
                table: "EconomicDependant");
        }
    }
}
