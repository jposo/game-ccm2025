﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

namespace GenericProject.Migrations
{
    public partial class excelnew : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "DocsExcel");

            migrationBuilder.CreateTable(
                name: "ExcelAll",
                columns: table => new
                {
                    Id = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Año = table.Column<string>(nullable: true),
                    Periodo = table.Column<string>(nullable: true),
                    NOEMPx = table.Column<string>(nullable: true),
                    Nombre = table.Column<string>(nullable: true),
                    ApPaterno = table.Column<string>(nullable: true),
                    ApMaterno = table.Column<string>(nullable: true),
                    RFC = table.Column<string>(nullable: true),
                    CURP = table.Column<string>(nullable: true),
                    IMSS = table.Column<string>(nullable: true),
                    ISSSTE = table.Column<string>(nullable: true),
                    Infonavit = table.Column<string>(nullable: true),
                    Compañía = table.Column<string>(nullable: true),
                    Vigencia = table.Column<string>(nullable: true),
                    Fecha_Alta = table.Column<string>(nullable: true),
                    Fecha_Baja = table.Column<string>(nullable: true),
                    Sexo = table.Column<string>(nullable: true),
                    Fecha_Nac = table.Column<string>(nullable: true),
                    Fecha_Reingreso = table.Column<string>(nullable: true),
                    Años_Ant = table.Column<string>(nullable: true),
                    Art100 = table.Column<string>(nullable: true),
                    CodigoPuesto = table.Column<string>(nullable: true),
                    Puesto = table.Column<string>(nullable: true),
                    NivelPuesto = table.Column<string>(nullable: true),
                    Dependencia = table.Column<string>(nullable: true),
                    Direccion = table.Column<string>(nullable: true),
                    Clave_Nodo = table.Column<string>(nullable: true),
                    Departamento = table.Column<string>(nullable: true),
                    CentroDeCostos = table.Column<string>(nullable: true),
                    FormaPago = table.Column<string>(nullable: true),
                    Banco = table.Column<string>(nullable: true),
                    ServMedicoPatron = table.Column<string>(nullable: true),
                    MontoSVida = table.Column<string>(nullable: true),
                    AguinaldoProporcional = table.Column<string>(nullable: true),
                    Adscripcion = table.Column<string>(nullable: true),
                    Horario = table.Column<string>(nullable: true),
                    Turno = table.Column<string>(nullable: true),
                    Generacion = table.Column<string>(nullable: true),
                    Sindicato = table.Column<string>(nullable: true),
                    Pension = table.Column<string>(nullable: true),
                    SalarioDiario = table.Column<string>(nullable: true),
                    SalarioIntegrado = table.Column<string>(nullable: true),
                    Tot_Percepciones = table.Column<string>(nullable: true),
                    Tot_Deducciones = table.Column<string>(nullable: true),
                    Neto = table.Column<string>(nullable: true),
                    _1SUELDO = table.Column<string>(nullable: true),
                    _2PENSIONADO = table.Column<string>(nullable: true),
                    _3DELEGADOS = table.Column<string>(nullable: true),
                    _4COMPENSACIONNORMAL = table.Column<string>(nullable: true),
                    _5COMPENSACIONNIVELACION = table.Column<string>(nullable: true),
                    _6COMPENSACIONANTIGUEDAD = table.Column<string>(nullable: true),
                    _7COMPENSACIONPOLICIA = table.Column<string>(nullable: true),
                    _8SERVICIOSESPECIALESD10 = table.Column<string>(nullable: true),
                    _9SERVICIOSESPECIALESTITULARESD10T = table.Column<string>(nullable: true),
                    _10ESTIMULO = table.Column<string>(nullable: true),
                    _11ESTIMULOALMANDO = table.Column<string>(nullable: true),
                    _17DEVDEINFONAVIT = table.Column<string>(nullable: true),
                    _18PRIMAVACACIONAL = table.Column<string>(nullable: true),
                    _22TRANSPORTE = table.Column<string>(nullable: true),
                    _23PRIMADERIESGO = table.Column<string>(nullable: true),
                    _24BONODERESPONSABILIDADES = table.Column<string>(nullable: true),
                    _50JUBILADO = table.Column<string>(nullable: true),
                    _59SUBSIDIOALEMPLEOINFORMATIVO = table.Column<string>(nullable: true),
                    _60COMPENSACION = table.Column<string>(nullable: true),
                    _70SUELDOTEMPORALESSINSERVMEDICO = table.Column<string>(nullable: true),
                    _101ISRSUELDO = table.Column<string>(nullable: true),
                    _102SERVICIOMEDICO = table.Column<string>(nullable: true),
                    _104FONDODEPENSIONES = table.Column<string>(nullable: true),
                    _107PRESTCORTOPLAZO = table.Column<string>(nullable: true),
                    _109PRESTHIPOTECARIO = table.Column<string>(nullable: true),
                    _110PRESTSINDICAL = table.Column<string>(nullable: true),
                    _111DEUDORESDIVERSOS = table.Column<string>(nullable: true),
                    _115FONACOT = table.Column<string>(nullable: true),
                    _116SERVMEDICOAPADRES = table.Column<string>(nullable: true),
                    _121CUOTASINDICATO1 = table.Column<string>(nullable: true),
                    _122DESCTOJUICIOMERCANTIL = table.Column<string>(nullable: true),
                    _124PENSIONALIMENTICIA1 = table.Column<string>(nullable: true),
                    _126PENSIONALIMENTICIA2 = table.Column<string>(nullable: true),
                    _127PENSIONALIMENTICIA3 = table.Column<string>(nullable: true),
                    _128PENSIONALIMENTICIA4 = table.Column<string>(nullable: true),
                    _130RETENCIONCREDITOINFONAVIT = table.Column<string>(nullable: true),
                    _132VIVIENDAPROMOTORA = table.Column<string>(nullable: true),
                    _133FONDOSINDICATO1 = table.Column<string>(nullable: true),
                    _138FONDOFUNERARIOSAITAHS = table.Column<string>(nullable: true),
                    _140SANCIONPORPENSIONALIMENTICIA = table.Column<string>(nullable: true),
                    _141AJUSTESUBSIDIO = table.Column<string>(nullable: true),
                    _144PRESTAMOSINDICALSAITAHS = table.Column<string>(nullable: true),
                    _146CUOTASINDICATO2 = table.Column<string>(nullable: true),
                    _147CUOTASINDICATO3 = table.Column<string>(nullable: true),
                    _148FONDOSINDICATO2 = table.Column<string>(nullable: true),
                    _151PRESTSINDICATO3 = table.Column<string>(nullable: true),
                    _155GASTOSINFRAESTRUCTURA = table.Column<string>(nullable: true),
                    _156PRESTAMOCORTOPLAZO = table.Column<string>(nullable: true),
                    _158CUOTASINDICATO4 = table.Column<string>(nullable: true),
                    _4001SUELDOR3 = table.Column<string>(nullable: true),
                    _4004COMPENSACIONNORMALR3 = table.Column<string>(nullable: true),
                    _4005COMPENSACIONNIVELACIONR3 = table.Column<string>(nullable: true),
                    _4008SERVICIOSESPECIALESD10R3 = table.Column<string>(nullable: true),
                    _4009SERVICIOSESPECIALESTITULARESD10TR3 = table.Column<string>(nullable: true),
                    _4010ESTIMULOR3 = table.Column<string>(nullable: true),
                    _4011ESTIMULOALMANDOR3 = table.Column<string>(nullable: true),
                    _4027AYUDAENERGIAELECTRICA = table.Column<string>(nullable: true),
                    _4097SUBSIDIOISR = table.Column<string>(nullable: true),
                    _4101ISRR3 = table.Column<string>(nullable: true),
                    _4197AJUSTESUBSIDIOALEMPLEADO = table.Column<string>(nullable: true),
                    PER = table.Column<string>(nullable: true),
                    DED = table.Column<string>(nullable: true),
                    NETO1 = table.Column<string>(nullable: true),
                    DIF = table.Column<string>(nullable: true),
                    PER1 = table.Column<string>(nullable: true),
                    DED1 = table.Column<string>(nullable: true),
                    NETO2 = table.Column<string>(nullable: true),
                    DIF1 = table.Column<string>(nullable: true),
                    Column1 = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_ExcelAll", x => x.Id);
                });
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "ExcelAll");

            migrationBuilder.CreateTable(
                name: "DocsExcel",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    CreationDate = table.Column<DateTime>(type: "datetime2", nullable: false),
                    FileName = table.Column<string>(type: "nvarchar(max)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_DocsExcel", x => x.Id);
                });
        }
    }
}
