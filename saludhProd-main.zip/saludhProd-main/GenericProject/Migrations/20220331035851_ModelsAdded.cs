﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

namespace GenericProject.Migrations
{
    public partial class ModelsAdded : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Employee",
                columns: table => new
                {
                    Id = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    CreationDate = table.Column<DateTime>(nullable: false),
                    Name = table.Column<string>(nullable: true),
                    PLastName = table.Column<string>(nullable: true),
                    MLastName = table.Column<string>(nullable: true),
                    Address = table.Column<string>(nullable: true),
                    Neighborhood = table.Column<string>(nullable: true),
                    PostalCode = table.Column<string>(nullable: true),
                    City = table.Column<string>(nullable: true),
                    Municipality = table.Column<string>(nullable: true),
                    State = table.Column<string>(nullable: true),
                    EmployeeNumber = table.Column<string>(nullable: true),
                    SignUpDate = table.Column<DateTime>(nullable: false),
                    Birthday = table.Column<DateTime>(nullable: false),
                    MaritalStatus = table.Column<int>(nullable: false),
                    Sex = table.Column<int>(nullable: false),
                    RFC = table.Column<string>(nullable: true),
                    TestamentWarning = table.Column<bool>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Employee", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "FileManager",
                columns: table => new
                {
                    Id = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Alias = table.Column<string>(nullable: true),
                    FileName = table.Column<string>(nullable: true),
                    EmployeeId = table.Column<int>(nullable: false),
                    BeneficiaryId = table.Column<int>(nullable: false),
                    TestamentId = table.Column<int>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_FileManager", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "EconomicDependant",
                columns: table => new
                {
                    Id = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    CreationDate = table.Column<DateTime>(nullable: false),
                    Relationship = table.Column<int>(nullable: false),
                    BirthDay = table.Column<DateTime>(nullable: false),
                    EmployeeId = table.Column<int>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_EconomicDependant", x => x.Id);
                    table.ForeignKey(
                        name: "FK_EconomicDependant_Employee_EmployeeId",
                        column: x => x.EmployeeId,
                        principalTable: "Employee",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "TesmamentedPeople",
                columns: table => new
                {
                    Id = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    CreationDate = table.Column<DateTime>(nullable: false),
                    Relationship = table.Column<int>(nullable: false),
                    Percentage = table.Column<int>(nullable: false),
                    EmployeeId = table.Column<int>(nullable: false),
                    isMain = table.Column<bool>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_TesmamentedPeople", x => x.Id);
                    table.ForeignKey(
                        name: "FK_TesmamentedPeople_Employee_EmployeeId",
                        column: x => x.EmployeeId,
                        principalTable: "Employee",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateIndex(
                name: "IX_EconomicDependant_EmployeeId",
                table: "EconomicDependant",
                column: "EmployeeId");

            migrationBuilder.CreateIndex(
                name: "IX_TesmamentedPeople_EmployeeId",
                table: "TesmamentedPeople",
                column: "EmployeeId");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "EconomicDependant");

            migrationBuilder.DropTable(
                name: "FileManager");

            migrationBuilder.DropTable(
                name: "TesmamentedPeople");

            migrationBuilder.DropTable(
                name: "Employee");
        }
    }
}
