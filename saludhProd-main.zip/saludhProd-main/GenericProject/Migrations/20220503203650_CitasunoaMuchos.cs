﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace GenericProject.Migrations
{
    public partial class CitasunoaMuchos : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_LaboratoryDocuments_Employee_EmployeeId",
                table: "LaboratoryDocuments");

            migrationBuilder.DropIndex(
                name: "IX_LaboratoryDocuments_EmployeeId",
                table: "LaboratoryDocuments");

            migrationBuilder.DropIndex(
                name: "IX_Appointment_EmployeeId",
                table: "Appointment");

            migrationBuilder.DropColumn(
                name: "EmployeeId",
                table: "LaboratoryDocuments");

            migrationBuilder.CreateIndex(
                name: "IX_Appointment_EmployeeId",
                table: "Appointment",
                column: "EmployeeId");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropIndex(
                name: "IX_Appointment_EmployeeId",
                table: "Appointment");

            migrationBuilder.AddColumn<int>(
                name: "EmployeeId",
                table: "LaboratoryDocuments",
                type: "int",
                nullable: true);

            migrationBuilder.CreateIndex(
                name: "IX_LaboratoryDocuments_EmployeeId",
                table: "LaboratoryDocuments",
                column: "EmployeeId");

            migrationBuilder.CreateIndex(
                name: "IX_Appointment_EmployeeId",
                table: "Appointment",
                column: "EmployeeId",
                unique: true);

            migrationBuilder.AddForeignKey(
                name: "FK_LaboratoryDocuments_Employee_EmployeeId",
                table: "LaboratoryDocuments",
                column: "EmployeeId",
                principalTable: "Employee",
                principalColumn: "Id",
                onDelete: ReferentialAction.Restrict);
        }
    }
}
