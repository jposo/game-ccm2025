using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace GenericProject.Views.Employees
{
    public class ThankYouModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
