﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using GenericProject.Data;
using GenericProject.Models;
using System.IO;

namespace GenericProject.Controllers
{
    public class LaboratoryDocumentsController : Controller
    {
        private readonly ApplicationContext _context;

        public LaboratoryDocumentsController(ApplicationContext context)
        {
            _context = context;
        }

        // GET: LaboratoryDocuments
        public async Task<IActionResult> Index()
        {
            var model = await _context.LaboratoryDocuments
                                        .Include(x => x.appointment)
                                        .Include(x => x.appointment.employee)
                                        .ToListAsync();

            return View(model);
            //var applicationContext = _context.LaboratoryDocuments.Include(l => l.appointment);


        }

        // GET: LaboratoryDocuments/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var laboratoryDocuments = await _context.LaboratoryDocuments
                .Include(l => l.appointment)
                .FirstOrDefaultAsync(m => m.Id == id);
            if (laboratoryDocuments == null)
            {
                return NotFound();
            }

            return View(laboratoryDocuments);
        }

        // GET: LaboratoryDocuments/Create}
        public IActionResult Create(int id)
        {
            LaboratoryDocuments model = new LaboratoryDocuments();
            model.AppointmentId = id;
            return View(model);
          
        }

        // POST: LaboratoryDocuments/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost("LaboratoryDocuments/Create")]
        public async Task<IActionResult> Create(LaboratoryDocuments laboratoryDocuments)
        {
            if (ModelState.IsValid)
            {
                if (laboratoryDocuments.File.Length > 0)
                {
                    var filePath = Path.Combine("wwwroot/", laboratoryDocuments.File.FileName);

                    using (var stream = System.IO.File.Create(filePath))
                    {
                        await laboratoryDocuments.File.CopyToAsync(stream);
                    }
                }
                laboratoryDocuments.nameDoc = laboratoryDocuments.File.FileName;
                _context.Add(laboratoryDocuments);
                await _context.SaveChangesAsync();
                return Redirect("/LaboratoryDocuments/Index/" + laboratoryDocuments.AppointmentId);
            }
           
            return View(laboratoryDocuments);
        }

        // GET: LaboratoryDocuments/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var laboratoryDocuments = await _context.LaboratoryDocuments.FindAsync(id);
            if (laboratoryDocuments == null)
            {
                return NotFound();
            }
            ViewData["AppointmentId"] = new SelectList(_context.Appointment, "Id", "Id", laboratoryDocuments.AppointmentId);
            return View(laboratoryDocuments);
        }

        // POST: LaboratoryDocuments/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("Id,nameDoc,Comment,AppointmentId")] LaboratoryDocuments laboratoryDocuments)
        {
            if (id != laboratoryDocuments.Id)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(laboratoryDocuments);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!LaboratoryDocumentsExists(laboratoryDocuments.Id))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            ViewData["AppointmentId"] = new SelectList(_context.Appointment, "Id", "Id", laboratoryDocuments.AppointmentId);
            return View(laboratoryDocuments);
        }

        // GET: LaboratoryDocuments/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var laboratoryDocuments = await _context.LaboratoryDocuments
                .Include(l => l.appointment)
                .FirstOrDefaultAsync(m => m.Id == id);
            if (laboratoryDocuments == null)
            {
                return NotFound();
            }

            return View(laboratoryDocuments);
        }

        // POST: LaboratoryDocuments/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var laboratoryDocuments = await _context.LaboratoryDocuments.FindAsync(id);
            _context.LaboratoryDocuments.Remove(laboratoryDocuments);
            await _context.SaveChangesAsync();
            return Redirect("/LaboratoryDocuments/Index/" + laboratoryDocuments.AppointmentId);
        }

        

        private bool LaboratoryDocumentsExists(int id)
        {
            return _context.LaboratoryDocuments.Any(e => e.Id == id);
        }
    }
}
