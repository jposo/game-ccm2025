﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using GenericProject.Data;
using GenericProject.Models;
using Microsoft.AspNetCore.Authorization;
using System.Web;
using Microsoft.AspNetCore.Identity;
using GenericProject.Areas.Identity.Data;
using GenericProject.Utilities;
using GenericProject.DTOs;

namespace GenericProject.Controllers
{
    public class AppointmentsController : Controller
    {
        private readonly ApplicationContext _context;
        private readonly UserManager<User> _userManager;
        private readonly GetUser _getUser;
        private readonly User currentUser;

        public AppointmentsController(ApplicationContext context, UserManager<User> userManager, GetUser getUser)
        {
            _getUser = getUser;
            _context = context;
            _userManager = userManager;
            currentUser = _getUser.CurrentUser();
        }


        /*
            public AppointmentsController(ApplicationContext context)
        {
            _context = context;
        }
        */
        // GET: Appointments
        public async Task<IActionResult> Index(int id)
        {
            User currentUser = _getUser.CurrentUser();
            var GetEmployeeByUserId = _context.Employee.Where(x => x.UserId == currentUser.Id).ToList();

            IList<string> roles = await _userManager.GetRolesAsync(currentUser);
            List<string> rolesList = roles.ToList();
            ViewBag.Rol = roles;

            var GetAppointmentsByEmployee = await _context.Appointment.Where(x => x.EmployeeId == id).Include(x => x.employee).ToListAsync();

            var output = new AppointmentOutput()
            {
                Appointments = GetAppointmentsByEmployee,
                EmployeeId = id
            };
            return View(output);

        }
        public async Task<IActionResult> CitedEmployee(int id)
        {
            var employee = await _context.Employee
                .FirstOrDefaultAsync(m => m.Id == id);

            employee.IsQuoted = true;
            _context.Update(employee);
            await _context.SaveChangesAsync();
            return Redirect("/employees/index");
        }
        public async Task<IActionResult> EndedAppointmentEmployee(int id)
        {
            var employee = await _context.Employee
                .FirstOrDefaultAsync(m => m.Id == id);

            employee.IsQuoted = false;
            _context.Update(employee);
            await _context.SaveChangesAsync();
            return Redirect("/employees/index/");
        }

        // GET: Appointments/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var appointment = await _context.Appointment
                .Include(a => a.employee)
                .FirstOrDefaultAsync(m => m.Id == id);
            if (appointment == null)
            {
                return NotFound();
            }

            return View(appointment);
        }

        // GET: Appointments/Create
        public IActionResult Create(int id)
        {
            var model = new Appointment();
            model.EmployeeId = id;
            return View(model);
        }

        // POST: Appointments/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("CreationDate, appointmentE, EmployeeId")] Appointment appointment)
        {
            if (ModelState.IsValid)
            {
                appointment.CreationDate = DateTime.Now;
                _context.Add(appointment);
                await _context.SaveChangesAsync();
                return Redirect("/Appointments/Index/" + appointment.EmployeeId);
            }
            // ViewData["EmployeeId"] = new SelectList(_context.Employee, "Id", "Id", appointment.EmployeeId);
            return View(appointment);
        }

        // GET: Appointments/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var appointment = await _context.Appointment.FindAsync(id);
            if (appointment == null)
            {
                return NotFound();
            }
            ViewData["EmployeeId"] = new SelectList(_context.Employee, "Id", "Id", appointment.EmployeeId);
            return View(appointment);
        }

        // POST: Appointments/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("Id,CreationDate,appointmentE,EmployeeId")] Appointment appointment)
        {
            if (id != appointment.Id)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(appointment);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!AppointmentExists(appointment.Id))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            ViewData["EmployeeId"] = new SelectList(_context.Employee, "Id", "Id", appointment.EmployeeId);
            return View(appointment);
        }

        // GET: Appointments/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var appointment = await _context.Appointment
                .Include(a => a.employee)
                .FirstOrDefaultAsync(m => m.Id == id);
            if (appointment == null)
            {
                return NotFound();
            }

            return View(appointment);
        }

        // POST: Appointments/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var appointment = await _context.Appointment.FindAsync(id);
            _context.Appointment.Remove(appointment);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool AppointmentExists(int id)
        {
            return _context.Appointment.Any(e => e.Id == id);
        }


    }
}
