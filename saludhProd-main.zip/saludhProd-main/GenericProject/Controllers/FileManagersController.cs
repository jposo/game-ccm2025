﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using GenericProject.Data;
using GenericProject.Models;
using System.IO;
using Microsoft.AspNetCore.Authorization;
using System.Web;
using Microsoft.AspNetCore.Identity;
using GenericProject.Areas.Identity.Data;
using GenericProject.Utilities;
using GenericProject.Migrations;

namespace GenericProject.Controllers
{
    public class FileManagersController : Controller
    {
        private readonly ApplicationContext _context;
        private readonly UserManager<User> _userManager;
        private readonly GetUser _getUser;
        private readonly User currentUser;

        public FileManagersController(ApplicationContext context, UserManager<User> userManager, GetUser getUser)
        {
            _getUser = getUser;
            _context = context;
            _userManager = userManager;
            currentUser = _getUser.CurrentUser();
        }

        // GET: FileManagers
        [HttpGet("FileManagers/Index/{type}/{id}")]
        public async Task<IActionResult> Index(string type, int id)
        {
            List<FileManager> files = new List<FileManager>();

            var GetFilesByEmployeeId = await _context.Employee
                                        .Include(x => x.EconomicDependants)
                                        .ThenInclude(x => x.FilesManager)
                                        .Include(x => x.TesmamentedPeoples)
                                        .ThenInclude(x => x.FilesManager)
                                        .Include(x => x.FilesManager)
                                        .FirstOrDefaultAsync(x => x.Id == id);

            files.AddRange(GetFilesByEmployeeId.FilesManager);
            files.AddRange(GetFilesByEmployeeId.EconomicDependants.SelectMany(x => x.FilesManager));
            files.AddRange(GetFilesByEmployeeId.TesmamentedPeoples.SelectMany(x => x.FilesManager));

            IList<string> roles = await _userManager.GetRolesAsync(currentUser);
            ViewBag.Rol = roles;

            return View(files);
        }

        // GET: FileManagers/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var fileManager = await _context.FileManager.Include(x => x.Employee).Include(x => x.EconomicDependant).Include(x => x.TesmamentedPeople)
                .FirstOrDefaultAsync(m => m.Id == id);
            if (fileManager == null)
            {
                return NotFound();
            }

            return View(fileManager);
        }

        // GET: FileManagers/Create
        [HttpGet("FileManagers/Create/{type}/{id:int}")]
        public IActionResult Create(string type, int id)
        {
            FileManager model = new FileManager();
            var userType = type;

            if (id > 0)
            {
                switch (userType)
                {
                    case "T":
                        model.TesmamentedPeopleId = id;
                        model.EmployeeId = null;
                        model.EconomicDependantId = null;
                        break;
                    case "E":
                        model.EmployeeId = id;
                        model.TesmamentedPeopleId = null;
                        model.EconomicDependantId = null;
                        break;
                    case "ED":
                        model.EconomicDependantId = id;
                        model.TesmamentedPeopleId = null;
                        model.EmployeeId = null;
                        break;
                    default:
                        break;
                }
                return View(model);
            }
            else
            {
                return View();
            }
        }

        // POST: FileManagers/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        public async Task<IActionResult> Create(FileManager fileManager)
        {
            FileManager model = new FileManager();
            if (ModelState.IsValid)
            {
                string type = "";
                int id = 0;
                if (fileManager.File.Length > 0)
                {
                    var filePath = Path.Combine("wwwroot/", fileManager.File.FileName);

                    using (var stream = System.IO.File.Create(filePath))
                    {
                        await fileManager.File.CopyToAsync(stream);
                    }
                }
                fileManager.FileName = fileManager.File.FileName;
                _context.Add(fileManager);

                if (fileManager.TesmamentedPeopleId != null)
                {
                    type = "T";
                    id = fileManager.TesmamentedPeopleId.Value;
                }
                if (fileManager.EconomicDependantId != null)
                {
                    type = "ED";
                    id = fileManager.EconomicDependantId.Value;
                }
                if (fileManager.EmployeeId != null)
                {
                    type = "E";
                    id = fileManager.EmployeeId.Value;
                }


                await _context.SaveChangesAsync();
                return Redirect("/fileManagers/Create/" + type + "/" + id);

            }
            return View(fileManager);
        }

        // GET: FileManagers/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var fileManager = await _context.FileManager.FindAsync(id);
            if (fileManager == null)
            {
                return NotFound();
            }
            return View(fileManager);
        }

        // POST: FileManagers/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, FileManager fileManager)
        {
            if (id != fileManager.Id)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(fileManager);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!FileManagerExists(fileManager.Id))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(fileManager);
        }

        // GET: FileManagers/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var fileManager = await _context.FileManager.Include(x => x.Employee).Include(x => x.EconomicDependant).Include(x => x.TesmamentedPeople)
                .FirstOrDefaultAsync(m => m.Id == id);
            if (fileManager == null)
            {
                return NotFound();
            }

            return View(fileManager);
        }

        // POST: FileManagers/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var fileManager = await _context.FileManager.FindAsync(id);
            _context.FileManager.Remove(fileManager);
            await _context.SaveChangesAsync();
            return Redirect("/filemanagers/Index/E/" + fileManager.EmployeeId);
        }
        private bool FileManagerExists(int id)
        {
            return _context.FileManager.Any(e => e.Id == id);
        }
    }
}
