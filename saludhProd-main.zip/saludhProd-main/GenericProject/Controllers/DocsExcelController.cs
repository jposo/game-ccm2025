﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using ExcelDataReader;
using Ganss.Excel;
using Newtonsoft.Json;
using System.Collections;
using System.IO;
using System.Text;
using GenericProject.Models;
using System.Collections.Generic;
using System.Linq;
using System;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using GenericProject.Data;

namespace GenericProject.Controllers
{
    public class DocsExcelController : Controller
    {
        private readonly ApplicationContext _context;

        public DocsExcelController(ApplicationContext context)
        {
            _context = context;
        }
        // GET: DocsExcel
        public async Task<IActionResult> Index()
        {
            var model = await _context.ExcelAll
                                       .ToListAsync();
            return View(model);
        }

        // GET: DocsExcel/Details/5
        public ActionResult Details(int id)
        {
            return View();
        }

        // GET: DocsExcel/Create
        public ActionResult Create()
        {
            
            return View();
        }

        // POST: DocsExcel/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create (IFormFile File)
        {
            if (ModelState.IsValid)
            {
                var test1 = new ExcelMapper(File.OpenReadStream()).Fetch<ExcelAll>();
                string json1 = JsonConvert.SerializeObject(test1, Formatting.Indented);

                //Guardar json en el server
                List<ExcelAll> finaloutput = JsonConvert.DeserializeObject<List<ExcelAll>>(json1); //mappear json, json1 = jsonconsulta
                _context.AddRange(finaloutput);
                await _context.SaveChangesAsync();
                return RedirectToAction("/DocsExcel/Index/");
            }
            
            return View();
        }

        // GET: DocsExcel/Edit/5
        public ActionResult Edit(int id)
        {
            return View();
        }

        // POST: DocsExcel/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(int id, IFormFile collection)
        {
            try
            {
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }

        // GET: DocsExcel/Delete/5
        public ActionResult Delete(int id)
        {
            return View();
        }

        // POST: DocsExcel/Delete/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Delete(int id, IFormCollection collection)
        {
            try
            {
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }
    }
}
