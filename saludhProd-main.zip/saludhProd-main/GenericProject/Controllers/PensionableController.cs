﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using GenericProject.Data;
using GenericProject.Models;
using GenericProject.Models.ViewModels;
using Microsoft.AspNetCore.Authorization;
using System.Web;
using Microsoft.AspNetCore.Identity;
using GenericProject.Areas.Identity.Data;
using GenericProject.Utilities;
using System.Data.SqlClient;
using System.Data;
using ExcelDataReader;
using Ganss.Excel;
using Newtonsoft.Json;
using System.Collections;
using System.IO;
using System.Text;
using System.Collections.Immutable;
using System.Linq.Expressions;
using System.Threading;
using GenericProject.Migrations;
using NPOI.OpenXmlFormats.Wordprocessing;
using Nancy.Session;
using NPOI.SS.Formula.Functions;
using OfficeOpenXml.FormulaParsing.Excel.Functions.Engineering;
using Org.BouncyCastle.Utilities.Encoders;
using static Microsoft.EntityFrameworkCore.DbLoggerCategory.Database;
using static NPOI.HSSF.Util.HSSFColor;
using System.Runtime.ConstrainedExecution;

namespace GenericProject.Controllers
{
    [Authorize]
    public class PensionableController : Controller
    {
        private readonly ApplicationContext _context;
        private readonly UserManager<User> _userManager;
        private readonly GetUser _getUser;
        private readonly User currentUser;

        public PensionableController(ApplicationContext context, UserManager<User> userManager, GetUser getUser)
        {
            _getUser = getUser;
            _context = context;
            _userManager = userManager;
            currentUser = _getUser.CurrentUser();
        }

        // GET: Employees
        public async Task<IActionResult> Index()
        {
            User currentUser = _getUser.CurrentUser();

            var GetEmployeeByUserId = await _context.Pensionable
                .Where(x => x.IsDeleted == false
                        && x.Status == StatusPensionable.Step9)
                .ToListAsync();

            var filesPensionable = await _context.FilePensionables
                                    .ToListAsync();

            bool IsAdministrador = false;

            IList<string> roles = await _userManager.GetRolesAsync(currentUser);
            List<string> rolesList = roles.ToList();
            ViewBag.Rol = roles;

            if (rolesList.Contains("Administrador"))
            {
                IsAdministrador = true;
            }

            if (IsAdministrador)
            {
                return View(await _context.Pensionable.Where(x => x.IsDeleted == false).ToListAsync());

            }

            return View(GetEmployeeByUserId);
        }
        public async Task<IActionResult> Report()
        {
            User currentUser = _getUser.CurrentUser();
            //List<Pensionable> pensionables = GetPensionablesWithFiles().ToList();

            var GetEmployeeByUserId = await _context.Pensionable
                .Where(x => x.IsDeleted == false && x.Status != StatusPensionable.Step1)
                .ToListAsync();
            List<FilePensionables> listAsync = await EntityFrameworkQueryableExtensions.ToListAsync<FilePensionables>(((IQueryable<FilePensionables>)_context.FilePensionables).Where(x => x.Tipo == Tipos.prePension || x.Tipo == Tipos.InformarBaja), new CancellationToken());

            //var filesPensionable = await _context.FilePensionables
            //    .ToListAsync();
            ViewBag.files = listAsync.ToList();

            //Pensionable pensionable = await _context.Pensionable.FindAsync((object)id);
            //    ViewBag.Pensionable = pensionable;
            //    var fileManager = await _context.FilePensionables.Include(x => x.EmployeeId)
            //        .FirstOrDefaultAsync(m => m.Id == id);


            return View(GetEmployeeByUserId);
        }
        public IQueryable<Pensionable> GetPensionablesWithFiles()
        {
            // Use IQueryable to include the Files navigation property
            IQueryable<Pensionable> pensionablesWithFiles = _context.Pensionable.Include(p => p.FilePensionables);
            return pensionablesWithFiles;
        }

        public User CurrentUser()
        {
            string userName = User.Identity.Name;
            var user = _context.Users.FirstOrDefault(x => x.Email == userName);

            return user;
        }

        // GET: Employees/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var employeePensionable = await _context.Pensionable
                .FirstOrDefaultAsync(m => m.Id == id);

            IList<string> roles = await _userManager.GetRolesAsync(currentUser);
            ViewBag.Rol = roles;

            if (employeePensionable == null)
            {
                return NotFound();
            }

            return View(employeePensionable);
        }

        // GET: Employees/Create
        public IActionResult Create()
        {
            Pensionable model = new Pensionable();
            return View(model);

        }

        public IActionResult ThankYou()
        {
            return View();
        }

        // POST: Employees/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details, see http://go.microsoft.com/fwlink/?LinkId=317598.


        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(Pensionable employeePensionable)
        {

            User currentUser = _getUser.CurrentUser();
            _context.Add(employeePensionable);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        public async Task<IActionResult> IndexDownload()
        {
            User currentUser = _getUser.CurrentUser();

            var GetEmployeeByUserId = await _context.Pensionable.Where(x => x.IsDeleted == false).ToListAsync();
            bool IsAdministrador = false;

            IList<string> roles = await _userManager.GetRolesAsync(currentUser);
            List<string> rolesList = roles.ToList();
            ViewBag.Rol = roles;

            if (rolesList.Contains("Administrador"))
            {
                IsAdministrador = true;
            }

            if (IsAdministrador)
            {
                return View(await _context.Pensionable.Where(x => x.IsDeleted == false).ToListAsync());

            }

            return View();
        }

        public async Task<IActionResult> ReportMonth()
        {
            User currentUser = _getUser.CurrentUser();

            var GetEmployeeByUserId = await _context.Pensionable.Where(x => x.IsDeleted == false).ToListAsync();
            bool IsAdministrador = false;

            IList<string> roles = await _userManager.GetRolesAsync(currentUser);
            List<string> rolesList = roles.ToList();
            ViewBag.Rol = roles;

            if (rolesList.Contains("Administrador"))
            {
                IsAdministrador = true;
            }

            if (IsAdministrador)
            {
                return View(await _context.Pensionable.Where(x => x.IsDeleted == false).ToListAsync());

            }

            return View();
        }

        // GET: Employees/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var employeePensionable = await _context.Pensionable.FindAsync(id);
            Console.WriteLine(employeePensionable.SueldoRegulador);
            if (employeePensionable == null)
            {
                return NotFound();
            }
            return View(employeePensionable);
        }

        // POST: Employees/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("Id,UserId,CreationDate,Name,PLastName,MLastName,Sex,Company,Job,TypePension,Address,Neighborhood,PostalCode,Tel, Cel, City,Municipality,State,Adscripcion,Departament,EmailE,EmployeeNumber,PensionNumber,Pension,SignUpDate,RetiredDate,Birthday,MaritalStatus,RFC,CURP,Generation,ETADate")] Pensionable employeePensionable)
        {
            List<string> varlist = new List<string>() {"CreationDate","Name","PLastName","MLastName","Sex","Company","Job","TypePension","Address","Neighborhood","PostalCode","Tel","Cel","City","Municipality","State","Adscripcion","Departament","EmailE","EmployeeNumber","PensionNumber","Pension","SignUpDate","RetiredDate","Birthday","MaritalStatus","RFC","CURP","Generation","ETADate"};

            Console.WriteLine(employeePensionable.SueldoRegulador);
            if (id != employeePensionable.Id)
            {
                return NotFound();
            }
            if (ModelState.IsValid)
            {
                try
                {
                    _context.Attach(employeePensionable);

                    foreach(string property in varlist)
                    {
                        _context.Entry(employeePensionable).Property(property).IsModified = true;
                    }

                    await _context.SaveChangesAsync();

                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!EmployeeExists(employeePensionable.Id))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(employeePensionable);
        }

        // GET: Employees/
        //
        // /5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var employeePensionable = await _context.Pensionable
                .FirstOrDefaultAsync(m => m.Id == id);
            if (employeePensionable == null)
            {
                return NotFound();
            }

            return View(employeePensionable);
        }

        // POST: Employees/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var employeePensionable = await _context.Pensionable.FirstOrDefaultAsync(x => x.Id == id);

            employeePensionable.IsDeleted = true;
            _context.Update(employeePensionable);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool EmployeeExists(int id)
        {
            return _context.Pensionable.Any(e => e.Id == id);
        }

        public async Task<IActionResult> DropedEmployee(int id)
        {
            var dropEmployee = await _context.Pensionable
                .Where(x => x.IsDeleted == true)
                .ToListAsync();

            return View("DropedEmployees", dropEmployee);
        }

        public async Task<IActionResult> FinalStatus()
        {
            var pensionablesFinalStatus = await _context.Pensionable
                .Where(x => x.Status == StatusPensionable.Step9)
                .ToListAsync();
            
            IList<string> roles = await _userManager.GetRolesAsync(currentUser);
            List<string> rolesList = roles.ToList();
            ViewBag.Rol = roles;


            return View("FinalStatus", pensionablesFinalStatus);

        }
        //public Task<ActionResult> GenerateExcel()
        //{
        //    // Assuming you have some data to pass to the Excel report generator
        //    List<ExcelDataModel> data = GetData();

        //    // File path where the Excel report will be saved
        //    string filePath = "path/to/your/excel/report.xlsx";

        //    // Create an instance of the ExcelReportGenerator class and call the method
        //    var excelReportGenerator = new ExcelReportGenerator();
        //    excelReportGenerator.GenerateExcelReport(filePath, data);

        //    return Content("Excel report generated successfully!");
        //}
    }
}
