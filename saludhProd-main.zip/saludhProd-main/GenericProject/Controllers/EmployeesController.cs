﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using GenericProject.Data;
using GenericProject.Models;
using GenericProject.Models.ViewModels;
using Microsoft.AspNetCore.Authorization;
using System.Web;
using Microsoft.AspNetCore.Identity;
using GenericProject.Areas.Identity.Data;
using GenericProject.Utilities;
using System.Data.SqlClient;
using System.Data;
using ExcelDataReader;
using Ganss.Excel;
using Newtonsoft.Json;
using System.Collections;
using System.IO;
using System.Text;

namespace GenericProject.Controllers
{
    [Authorize]
    public class EmployeesController : Controller
    {
        private readonly ApplicationContext _context;
        private readonly UserManager<User> _userManager;
        private readonly GetUser _getUser;
        private readonly User currentUser;

        public EmployeesController(ApplicationContext context, UserManager<User> userManager, GetUser getUser)
        {
            _getUser = getUser;
            _context = context;
            _userManager = userManager;
            currentUser = _getUser.CurrentUser();
        }

        // GET: Employees
        public async Task<IActionResult> Index()
        {

            User currentUser = _getUser.CurrentUser();

            var GetEmployeeByUserId = await _context.Employee.Where(x=> x.IsDeleted == false).ToListAsync();
            bool IsAdministrador = false;

            IList<string> roles = await _userManager.GetRolesAsync(currentUser);
            List<string> rolesList = roles.ToList();
            ViewBag.Rol = roles;

            if (rolesList.Contains("Administrador"))
            {
                IsAdministrador = true;
            }

            if (IsAdministrador)
            {
                return View(await _context.Employee.Where(x => x.IsDeleted == false).ToListAsync());

            }
            if (rolesList.Contains("Doctora"))
            {
                var employeeVer = await _context.Employee.Where(x => x.IsVerified == true && x.IsDeleted == false).ToListAsync();

                return View("EmployeeDoc", employeeVer);
            }
            if (rolesList.Contains("Proveedores"))
            {
                var emplo = await _context.Employee.Where(x => x.IsDeleted == false).ToListAsync();
                return View("EmployeeProveedor", emplo);
            }

            return View(GetEmployeeByUserId);
        }

        public async Task<IActionResult> IndexDownload()
        {
            User currentUser = _getUser.CurrentUser();

            var GetEmployeeByUserId = await _context.Employee.Where(x=> x.IsDeleted == false).ToListAsync();
            bool IsAdministrador = false;

            IList<string> roles = await _userManager.GetRolesAsync(currentUser);
            List<string> rolesList = roles.ToList();
            ViewBag.Rol = roles;

            if (rolesList.Contains("Administrador"))
            {
                IsAdministrador = true;
            }

            if (IsAdministrador)
            {
                return View(await _context.Employee.Where(x => x.IsDeleted == false).ToListAsync());

            }
           
            return View();
        }

        [HttpPost]
        public ActionResult Json(DataTableDefaultPost model)
        {
            List<TableEmployeeViewModel> employees = new List<TableEmployeeViewModel>();
            int employeesCount = _context.Employee.Count();
            string sortBy = model.order[0].column == 0 ? "employeeNumber" : model.columns[model.order[0].column].data;
            bool sortDir = model.order[0].dir == "asc";


            if (String.IsNullOrEmpty(model.search.value))
            {
                employees = _context.Employee.Skip(model.start * model.length).Take(model.length).ToList().Select(x => new TableEmployeeViewModel(x)).ToList();
                return Json(new
                {
                    draw = model.draw,
                    recordsTotal = employeesCount,
                    recordFiltered = employees.Count,
                    data = employees
                });
            }

            employees = _context.Employee
            .Where(x => x.Adscripcion.Contains(model.search.value) || x.CURP.Contains(model.search.value) || x.EmployeeNumber.Contains(model.search.value)
                                                     || x.MLastName.Contains(model.search.value) || x.PLastName.Contains(model.search.value) || x.Name.Contains(model.search.value) || x.RFC.Contains(model.search.value))
                                                    .Skip(model.start * model.length).Take(model.length)
                                                    .ToList().Select(x => new TableEmployeeViewModel(x)).ToList();
            return Json(new
            {
                draw = model.draw,
                recordsTotal = employeesCount,
                recordFiltered = employees.Count,
                data = employees
            });
        }

        public User CurrentUser()
        {
            string userName = User.Identity.Name;
            var user = _context.Users.FirstOrDefault(x => x.Email == userName);

            return user;
        }

        // GET: Employees/Details/5
        public async Task<IActionResult> Details(int id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var employee = await _context.Employee
                .FirstOrDefaultAsync(m => m.Id == id);

            var testamentarians = new List<TesmamentedPeople>();
            var economicDependats = new List<EconomicDependant>();

            testamentarians = await _context.TesmamentedPeople.Where(m => m.EmployeeId == id).ToListAsync();
            economicDependats = await _context.EconomicDependant.Where(m => m.EmployeeId == id).ToListAsync();

            ViewBag.testament = testamentarians;
            ViewBag.economic = economicDependats;
            IList<string> roles = await _userManager.GetRolesAsync(currentUser);
            ViewBag.Rol = roles;

            if (employee == null)
            {
                return NotFound();
            }

            return View(employee);
        }

        // GET: Employees/Create
        public IActionResult Create()
        {
            return View();
        }

        public IActionResult ThankYou()
        {
            return View();
        }

        // POST: Employees/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details, see http://go.microsoft.com/fwlink/?LinkId=317598.


        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("Id,CreationDate,Name,PLastName,MLastName,Adscripcion, Address,Neighborhood,PostalCode,Tel, Cel, City,Municipality,State,Departament, TypeEmployee, EmailE,EmployeeNumber,SignUpDate,Birthday,MaritalStatus,Sex,RFC,CURP,TestamentWarning")] Employee employee)
        {

            User currentUser = _getUser.CurrentUser();
            employee.UserId = currentUser.Id;
            _context.Add(employee);
            await _context.SaveChangesAsync();


            if (User.Identity.IsAuthenticated)
            {
                return RedirectToAction(nameof(Index));
            }

            else
            {
                return RedirectToAction(nameof(ThankYou));
            }
        }

        // GET: Employees/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var employee = await _context.Employee.FindAsync(id);
            if (employee == null)
            {
                return NotFound();
            }
            return View(employee);
        }

        // POST: Employees/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("Id,CreationDate,Name,PLastName,MLastName,Adscripcion, Address,Neighborhood,PostalCode,Tel, Cel, City,Municipality,State,Departament, TypeEmployee,EmailE,EmployeeNumber,SignUpDate,Birthday,MaritalStatus,Sex,RFC,CURP,TestamentWarning")] Employee employee)
        {
            if (id != employee.Id)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(employee);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!EmployeeExists(employee.Id))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(employee);
        }

        [HttpPost]
        public async Task<IActionResult> Search(string employeeNum)
        {

            var empleado = _context.ExcelAll.FirstOrDefault(m => m.NOEMPx == employeeNum); //consulta

            Employee ToView = new Employee
            {
                Name = empleado.Nombre,
                PLastName = empleado.ApPaterno,
                MLastName = empleado.ApMaterno,
                EmployeeNumber = empleado.NOEMPx,
                RFC = empleado.RFC,
                CURP = empleado.CURP
            };

            return View(ToView);
        }

        // GET: Employees/
        //
        // /5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var employee = await _context.Employee
                .FirstOrDefaultAsync(m => m.Id == id);
            if (employee == null)
            {
                return NotFound();
            }

            return View(employee);
        }

        // POST: Employees/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var employee = await _context.Employee.FirstOrDefaultAsync(x => x.Id == id);

            employee.IsDeleted = true;
            _context.Update(employee);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool EmployeeExists(int id)
        {
            return _context.Employee.Any(e => e.Id == id);
        }

        public async Task<IActionResult> DocumentsLaboratoryEmployee(int id)
        {
            var GetDocumentsLaboratoryByEmployee = await _context.LaboratoryDocuments.Where(x => x.appointment.EmployeeId == id).Include(x => x.appointment).Include(x => x.appointment.employee).ToListAsync();

            return View(GetDocumentsLaboratoryByEmployee);
        }
        public async Task<IActionResult> ValidateEmployee(int id)
        {
            var employee = await _context.Employee
                .FirstOrDefaultAsync(m => m.Id == id);

            employee.IsVerified = true;
            _context.Update(employee);
            await _context.SaveChangesAsync();
            return RedirectToAction("Index");
        }


        public async Task<IActionResult> RejectEmployee(int id)
        {
            var employee = await _context.Employee
                .FirstOrDefaultAsync(m => m.Id == id);

            employee.IsVerified = false;
            _context.Update(employee);
            await _context.SaveChangesAsync();
            return RedirectToAction("Index");
        }

        public async Task<IActionResult> DropedEmployee (int id)
        {
            var dropEmployee = await _context.Employee.Where(x => x.IsDeleted == true).ToListAsync();
            return View("DropedEmployees", dropEmployee);
        }
    }
}
