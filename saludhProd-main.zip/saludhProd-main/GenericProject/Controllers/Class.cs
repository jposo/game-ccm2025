﻿namespace GenericProject.Controllers
{
    public class Class
    {
    }
}
