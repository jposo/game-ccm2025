﻿//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Threading.Tasks;
//using Microsoft.AspNetCore.Mvc;
//using Microsoft.AspNetCore.Mvc.Rendering;
//using Microsoft.EntityFrameworkCore;
//using GenericProject.Data;
//using GenericProject.Models;
//using GenericProject.Models.ViewModels;
//using Microsoft.AspNetCore.Authorization;
//using System.Web;
//using Microsoft.AspNetCore.Identity;
//using GenericProject.Areas.Identity.Data;
//using GenericProject.Utilities;
//using System.Data.SqlClient;
//using System.Data;
//using ExcelDataReader;
//using Ganss.Excel;
//using Newtonsoft.Json;
//using System.Collections;
//using System.IO;
//using System.Text;
//using Microsoft.AspNetCore.Http;

//namespace GenericProject.Controllers
//{
//    public class StepsController : Controller
//    {
//        private readonly ApplicationContext _context;

//        public StepsController(ApplicationContext context)
//        {
//            _context = context;
//        }

//        // GET: FilesPensionables
//        public async Task<IActionResult> Index()
//        {
//            var model = await _context.Pensionable
//                .ToListAsync();

//            return View(model);
//            //var applicationContext = _context.FilesStep1.Include(l => l.appointment);


//        }

//        // GET: FilesStep1/Details/5
//        public async Task<IActionResult> Details(int? id)
//        {
//            if (id == null)
//            {
//                return NotFound();
//            }

//            var FilesStep1 = await _context.FilesStep1
//                .FirstOrDefaultAsync(m => m.Id == id);
//            if (FilesStep1 == null)
//            {
//                return NotFound();
//            }

//            return View(FilesStep1);
//        }

//        // GET: FilesStep1/Create}
//        public IActionResult Create(int id)
//        {
//            var model = _context.Pensionable
//                .FirstOrDefault(m => m.Id == id);

//            Pensionable pensionable = new Pensionable();
//            TablePensionablesViewModel modelPensionable = new TablePensionablesViewModel(pensionable);

//            return View(modelPensionable);

//        }

//        // POST: FilesStep1/Create
//        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
//        // more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
//        [HttpPost("FilesStep1/Create")]
//        public async Task<IActionResult> Create(TablePensionablesViewModel model)
//        {
//            if (!ModelState.IsValid)
//                return View(model);

//            var filesPensionable = await _context.Pensionable.FindAsync(model.EmployeeId);

//            if (filesPensionable == null)
//            {
//                ModelState.AddModelError("", "Pensionable no encontrado");
//                return View(model);
//            }

//            model.EmployeeNumber = filesPensionable.EmployeeNumber;

//            await CreateFile(model.NameDocFile, model.URLDoc);


//            model.URLDoc = model.NameDocFile;

//            _context.Add(model);

//            filesPensionable.Status = StatusPensionable.Step2;
//            await _context.SaveChangesAsync();

//            return Redirect("/Pensionable/Details/" + model.EmployeeId);
//        }


//        public IActionResult Step2(int id)
//        {
//            FilesStep2 model = _context.FilesStep2.FirstOrDefault(f => f.EmployeeId == id);
//            return View(model);

//        }

//        async Task CreateFile(string fileName, IFormFile file) //, FileTypes fileType)

//        {
//            if (file.Length == 0)
//                return;

//            var filePath = Path.Combine("wwwroot/", fileName);

//            using var stream = System.IO.File.Create(filePath);

//            await file.CopyToAsync(stream);

//            //var fileModel = new FileModel
//            //{
//            //    FileType = fileType,
//            //    FileName = fileName,
//            //   //TODO: Katrina adds more fields here, using parameters and stuff
//            //};

//            //_context.Add(fileModel);
//        }

//        [HttpPost("FilesStep2/Step2")]
//        public async Task<IActionResult> Step2(FilesStep2 model)
//        {
//            if (!ModelState.IsValid)
//                return View(model);

//            FilesStep2 filePensionable = await _context.FilesStep2
//                .Include(f => f.Pensionable)
//                .FirstOrDefaultAsync(f => f.Id == model.Id);

//            await CreateFile(model.DocFichaPermiso.FileName, model.DocFichaPermiso);
//            await CreateFile(model.DocIngresoPermiso.FileName, model.DocIngresoPermiso);

//            filePensionable.FileFichaPermiso = model.DocFichaPermiso.FileName;
//            filePensionable.FileIngresoPermiso = model.DocIngresoPermiso.FileName;

//            filePensionable.Pensionable.Status = StatusPensionable.Step3;
//            await _context.SaveChangesAsync();
//            return Redirect("/Pensionable/Details/" + filePensionable.Pensionable.Id);
//        }

//        // GET: FilesStep2/Edit/5
//        public async Task<IActionResult> Edit(int? id)
//        {
//            if (id == null)
//            {
//                return NotFound();
//            }

//            var FilesPensionables = await _context.FilesPensionables.FindAsync(id);
//            if (FilesPensionables == null)
//            {
//                return NotFound();
//            }
//            //ViewData["AppointmentId"] = new SelectList(_context.Appointment, "Id", "Id", FilesPensionables.AppointmentId);
//            return View(FilesPensionables);
//        }

//        // POST: FilesPensionables/Edit/5
//        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
//        // more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
//        [HttpPost]
//        [ValidateAntiForgeryToken]
//        public async Task<IActionResult> Edit(int id, [Bind("Id,nameDoc,Comment,AppointmentId")] FilesPensionables FilesPensionables)
//        {
//            if (id != FilesPensionables.Id)
//            {
//                return NotFound();
//            }

//            if (ModelState.IsValid)
//            {
//                try
//                {
//                    _context.Update(FilesPensionables);
//                    await _context.SaveChangesAsync();
//                }
//                catch (DbUpdateConcurrencyException)
//                {
//                    if (!FilesPensionablesExists(FilesPensionables.Id))
//                    {
//                        return NotFound();
//                    }
//                    else
//                    {
//                        throw;
//                    }
//                }
//                return RedirectToAction(nameof(Index));
//            }
//            ViewData["AppointmentId"] = new SelectList(_context.Appointment, "Id", "Id", FilesPensionables.Pensionable.Id);
//            return View(FilesPensionables);
//        }

//        // GET: FilesPensionables/Delete/5
//        public async Task<IActionResult> Delete(int? id)
//        {
//            if (id == null)
//            {
//                return NotFound();
//            }

//            var FilesPensionables = await _context.FilesPensionables
//                .FirstOrDefaultAsync(m => m.Id == id);
//            if (FilesPensionables == null)
//            {
//                return NotFound();
//            }

//            return View(FilesPensionables);
//        }

//        // POST: FilesPensionables/Delete/5
//        [HttpPost, ActionName("Delete")]
//        [ValidateAntiForgeryToken]
//        public async Task<IActionResult> DeleteConfirmed(int id)
//        {
//            var FilesPensionables = await _context.FilesPensionables.FindAsync(id);
//            _context.FilesPensionables.Remove(FilesPensionables);
//            await _context.SaveChangesAsync();
//            return Redirect("/FilesPensionables/Index/" + FilesPensionables.Pensionable.Id);
//        }



//        private bool FilesPensionablesExists(int id)
//        {
//            return _context.FilesPensionables.Any(e => e.Id == id);
//        }
//    }
//}
