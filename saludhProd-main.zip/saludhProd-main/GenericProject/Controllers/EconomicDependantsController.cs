﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using GenericProject.Data;
using GenericProject.Models;
using GenericProject.Areas.Identity.Data;
using GenericProject.Utilities;
using Microsoft.AspNetCore.Identity;

namespace GenericProject.Controllers
{
    public class EconomicDependantsController : Controller
    {
        private readonly ApplicationContext _context;
        private readonly UserManager<User> _userManager;
        private readonly GetUser _getUser;
        private readonly User currentUser;

        public EconomicDependantsController(ApplicationContext context, UserManager<User> userManager, GetUser getUser)
        {
            _getUser = getUser;
            _context = context;
            _userManager = userManager;
            currentUser = _getUser.CurrentUser();
        }

        // GET: EconomicDependants
        public async Task<IActionResult> Index()
        {
            var applicationContext = _context.EconomicDependant.Where(x=> x.IsDeleted == false).Include(e => e.employee);
            return View(await applicationContext.ToListAsync());
        }

        public async Task<IActionResult> IndexDownload()
        {
            var applicationContext = _context.EconomicDependant.Where(x => x.IsDeleted == false).Include(e => e.employee);
            return View(await applicationContext.ToListAsync());
        }

        // GET: EconomicDependants/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            IList<string> roles = await _userManager.GetRolesAsync(currentUser);
            ViewBag.Rol = roles;

            if (id == null)
            {
                return NotFound();
            }

            var economicDependant = await _context.EconomicDependant
                .Include(e => e.employee)
                .FirstOrDefaultAsync(m => m.Id == id);
            if (economicDependant == null)
            {
                return NotFound();
            }

            return View(economicDependant);
        }

        // GET: EconomicDependants/Create
        public IActionResult Create(int id)
        {
            EconomicDependant model = new EconomicDependant();
            model.EmployeeId = id;

            return View(model);
        }

        // POST: EconomicDependants/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("CreationDate,Name,Relationship,CURP,BirthDay,EmployeeId,EmployeeNumber")] EconomicDependant economicDependant)
        {
            if (ModelState.IsValid)
            {
                _context.Add(economicDependant);
                await _context.SaveChangesAsync();
                return Redirect("/Employees/Details/" + economicDependant.EmployeeId);
            }
            ViewData["EmployeeId"] = new SelectList(_context.Employee, "Id", "Id", economicDependant.EmployeeId);
            ViewData["EmployeeNumber"] = new SelectList(_context.Employee, "EmployeeNumber", "EmployeeNumber", economicDependant.EmployeeNumber);
            return View(economicDependant);
        }

        // GET: EconomicDependants/Edit/
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var economicDependant = await _context.EconomicDependant.FindAsync(id);
            if (economicDependant == null)
            {
                return NotFound();
            }
            ViewData["EmployeeId"] = new SelectList(_context.Employee, "Id", "Id", economicDependant.EmployeeId);
            return View(economicDependant);
        }

        // POST: EconomicDependants/Edit/
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("Id,CreationDate,EmployeeId,EmployeeNumber,Name,CURP,Relationship,BirthDay")] EconomicDependant economicDependant)
        {
            if (id != economicDependant.Id)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(economicDependant);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!EconomicDependantExists(economicDependant.Id))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return Redirect("/Employees/Details/" + economicDependant.EmployeeId);
            }
            ViewData["EmployeeId"] = new SelectList(_context.Employee, "Id", "Id", economicDependant.EmployeeId);
            ViewData["EmployeeNumber"] = new SelectList(_context.Employee, "EmployeeNumber", "EmployeeNumber", economicDependant.EmployeeNumber);
            return View(economicDependant);
        }

        // GET: EconomicDependants/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var economicDependant = await _context.EconomicDependant
                .Include(e => e.employee)
                .FirstOrDefaultAsync(m => m.Id == id);
            if (economicDependant == null)
            {
                return NotFound();
            }

            return View(economicDependant);
        }

        // POST: EconomicDependants/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var economicDependant = await _context.EconomicDependant.FirstOrDefaultAsync(x => x.Id == id);
            economicDependant.IsDeleted = true;
            _context.Update(economicDependant);
            await _context.SaveChangesAsync();
            return Redirect("/Employees/Details/" + economicDependant.EmployeeId);
        }

        private bool EconomicDependantExists(int id)
        {
            return _context.EconomicDependant.Any(e => e.Id == id);
        }
    }
}
