﻿using GenericProject.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Identity;
using GenericProject.Areas.Identity.Data;
using GenericProject.Utilities;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using GenericProject.Data;
using System.Web;
using Microsoft.AspNetCore.Http;
using ExcelDataReader;
using Ganss.Excel;
using Newtonsoft.Json;
using System.Collections;
using System.IO;
using System.Text;

namespace GenericProject.Controllers
{
    public class HomeController : Controller
    {
        private readonly ApplicationContext _context;
        private readonly UserManager<User> _userManager;
        private readonly GetUser _getUser;
        private readonly User currentUser;

        public HomeController(ApplicationContext context, UserManager<User> userManager, GetUser getUser)
        {
            _getUser = getUser;
            _context = context;
            _userManager = userManager;
            currentUser = _getUser.CurrentUser();
        }
        //private readonly ILogger<HomeController> _logger;

        public User CurrentUser()
        {
            string userName = User.Identity.Name;
            var user = _context.Users.FirstOrDefault(x => x.Email == userName);

            return user;
        }
        public async Task<IActionResult> Index()
        {
            //var file = "C:\\Users\\Karin\\source\\repos\\generic-project-with-login\\GenericProject\\Excel/Ejemplo_base XIPE.xlsx";

            //var test1 = new ExcelMapper(file).Fetch<ExcelAll>();
            //string json1 = JsonConvert.SerializeObject(test1, Formatting.Indented);

            ////Guardar json en el server
            //var inputFromFront = "000004";
            //List<ExcelAll> finaloutput = JsonConvert.DeserializeObject<List<ExcelAll>>(json1); //mappear json, json1 = jsonconsulta
            //var empleado = finaloutput.FirstOrDefault(m => m.NOEMPx == inputFromFront); //consulta

            //var debug = "";

            User currentUser = _getUser.CurrentUser();
            if (currentUser == null)
            {
                return Redirect("Identity/Account/Login");
            }
            IList<string> roles = await _userManager.GetRolesAsync(currentUser);
            List<string> rolesList = roles.ToList();
            ViewBag.Rol = roles;
            return View();
        }

        //public ActionResult exportar()
        //{
        //    DataTable dt

        //    return Json("Exportar Exito", JsonRequestBehavior.AllowGet);
        //}

        public IActionResult Privacy()
        {
            return View();
        }

        public IActionResult Download()
        {
            return View();
        }
        public async Task<IActionResult> DivisionUser()
        {
            User currentUser = _getUser.CurrentUser();
            if (currentUser == null)
            {
                return Redirect("Identity/Account/Login");
            }
            IList<string> roles = await _userManager.GetRolesAsync(currentUser);
            List<string> rolesList = roles.ToList();
            ViewBag.Rol = roles;
            return View();
        }

        public async Task<IActionResult> DivisionRetired()
        {
            User currentUser = _getUser.CurrentUser();
            if (currentUser == null)
            {
                return Redirect("Identity/Account/Login");
            }
            IList<string> roles = await _userManager.GetRolesAsync(currentUser);
            List<string> rolesList = roles.ToList();
            ViewBag.Rol = roles;
            return View();
        }

        public async Task<IActionResult> DivisionPensionable()
        {
            User currentUser = _getUser.CurrentUser();
            if (currentUser == null)
            {
                return Redirect("Identity/Account/Login");
            }
            IList<string> roles = await _userManager.GetRolesAsync(currentUser);
            List<string> rolesList = roles.ToList();
            ViewBag.Rol = roles;
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
