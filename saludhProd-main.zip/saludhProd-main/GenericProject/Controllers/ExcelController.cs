﻿using Microsoft.AspNetCore.Mvc;

namespace GenericProject.Controllers
{
    public class ExcelController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
