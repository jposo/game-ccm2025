﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using GenericProject.Data;
using GenericProject.Models;
using GenericProject.Areas.Identity.Data;
using GenericProject.Utilities;
using Microsoft.AspNetCore.Identity;

namespace GenericProject.Controllers
{
    public class TesmamentedPeoplesController : Controller
    {
        private readonly ApplicationContext _context;
        private readonly UserManager<User> _userManager;
        private readonly GetUser _getUser;
        private readonly User currentUser;

        public TesmamentedPeoplesController(ApplicationContext context, UserManager<User> userManager, GetUser getUser)
        {
            _getUser = getUser;
            _context = context;
            _userManager = userManager;
            currentUser = _getUser.CurrentUser();
        }

        // GET: TesmamentedPeoples
        public async Task<IActionResult> Index()
        {
            var applicationContext = _context.TesmamentedPeople.Where(x => x.IsDeleted == false).Include(t => t.Employee);
            return View(await applicationContext.ToListAsync());
        }

        public async Task<IActionResult> IndexDownload()
        {
            var applicationContext = _context.TesmamentedPeople.Where(x => x.IsDeleted == false).Include(t => t.Employee);
            return View(await applicationContext.ToListAsync());
        }

        // GET: TesmamentedPeoples/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            IList<string> roles = await _userManager.GetRolesAsync(currentUser);
            ViewBag.Rol = roles;

            if (id == null)
            {
                return NotFound();
            }

            var tesmamentedPeople = await _context.TesmamentedPeople
                .Include(t => t.Employee)
                .FirstOrDefaultAsync(m => m.Id == id);
            if (tesmamentedPeople == null)
            {
                return NotFound();
            }

            return View(tesmamentedPeople);
        }

        // GET: TesmamentedPeoples/Create
        public IActionResult Create(int id)
        {
            TesmamentedPeople model = new TesmamentedPeople();
            model.EmployeeId = id;

            return View(model);
        }

        // POST: TesmamentedPeoples/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("CreationDate,Name,Relationship,CURP,Percentage,EmployeeId,isMain")] TesmamentedPeople tesmamentedPeople)
        {
            if (ModelState.IsValid)
            {
                _context.Add(tesmamentedPeople);
                await _context.SaveChangesAsync();
                return Redirect("/Employees/Details/" + tesmamentedPeople.EmployeeId);
            }
            ViewData["EmployeeId"] = new SelectList(_context.Employee, "Id", "Id", tesmamentedPeople.EmployeeId);
            return View(tesmamentedPeople);
        }

        // GET: TesmamentedPeoples/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var tesmamentedPeople = await _context.TesmamentedPeople.FindAsync(id);
            if (tesmamentedPeople == null)
            {
                return NotFound();
            }
            ViewData["EmployeeId"] = new SelectList(_context.Employee, "Id", "Id", tesmamentedPeople.EmployeeId);
            return View(tesmamentedPeople);
        }

        // POST: TesmamentedPeoples/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("Id,CreationDate,Name,CURP,Relationship,Percentage,EmployeeId,isMain")] TesmamentedPeople tesmamentedPeople)
        {
            if (id != tesmamentedPeople.Id)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(tesmamentedPeople);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!TesmamentedPeopleExists(tesmamentedPeople.Id))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            ViewData["EmployeeId"] = new SelectList(_context.Employee, "Id", "Id", tesmamentedPeople.EmployeeId);
            return View(tesmamentedPeople);
        }

        // GET: TesmamentedPeoples/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var tesmamentedPeople = await _context.TesmamentedPeople
                .Include(t => t.Employee)
                .FirstOrDefaultAsync(m => m.Id == id);
            if (tesmamentedPeople == null)
            {
                return NotFound();
            }

            return View(tesmamentedPeople);
        }

        // POST: TesmamentedPeoples/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var tesmamentedPeople = await _context.TesmamentedPeople.FirstOrDefaultAsync(x => x.Id == id);

            tesmamentedPeople.IsDeleted = true;
            _context.Update(tesmamentedPeople);
            await _context.SaveChangesAsync();
            return Redirect("/Employees/Details/" + tesmamentedPeople.EmployeeId);
        }

        private bool TesmamentedPeopleExists(int id)
        {
            return _context.TesmamentedPeople.Any(e => e.Id == id);
        }
    }
}
