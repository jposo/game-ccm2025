﻿using Microsoft.AspNetCore.Mvc;

namespace GenericProject.Controllers
{
    public class HomeController1 : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
