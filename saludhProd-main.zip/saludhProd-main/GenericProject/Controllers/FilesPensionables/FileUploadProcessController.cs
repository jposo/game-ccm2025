﻿using GenericProject.Areas.Identity.Data;
using GenericProject.Data;
using GenericProject.Models;
using GenericProject.Models.ViewModels;
using GenericProject.Utilities;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Nancy.Session;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Linq.Expressions;
using System.Threading;
using System.Threading.Tasks;

namespace GenericProject.Controllers
{
    public class FileUploadProcessController : Controller
    {
        private readonly
#nullable disable
        ApplicationContext _context;
        private readonly UserManager<User> _userManager;
        private readonly GetUser _getUser;
        private readonly User currentUser;
        private readonly IWebHostEnvironment _env;
        private List<FilePensionables> Pensionables = new List<FilePensionables>();

        public FileUploadProcessController(ApplicationContext context, UserManager<User> userManager, GetUser getUser)
        {
            _getUser = getUser;
            _context = context;
            _userManager = userManager;
            currentUser = _getUser.CurrentUser();
        } 

        //[HttpGet("FileUploadProcess/Index/{type}/{id}")]
        public async Task<IActionResult> Index(int id)
        {
            FileUploadProcessController processController = this;
            IList<string> roles = await _userManager.GetRolesAsync(currentUser);
            ViewBag.Rol = roles;
            Pensionable pensionable = await processController._context.Pensionable.FindAsync((object)id);
            ViewBag.Pensionable = pensionable;
            List<FilePensionables> listAsync = await EntityFrameworkQueryableExtensions.ToListAsync<FilePensionables>(((IQueryable<FilePensionables>)processController._context.FilePensionables).Where<FilePensionables>((Expression<Func<FilePensionables, bool>>)(x =>  x.EmployeeId == id)), new CancellationToken());
            if (listAsync == null)
                return (IActionResult)processController.NotFound();
            return (IActionResult)processController.View((object)new TablePensionablesViewModel(id, 0)
            {
                FilesPensionable = listAsync
            });
            
        }
        //public async Task<IActionResult> Details(int? id)
        //{
        //    if (id == null)
        //    {
        //        return NotFound();
        //    }
        //    Pensionable pensionable = await _context.Pensionable.FindAsync((object)id);
        //    ViewBag.Pensionable = pensionable;
        //    var fileManager = await _context.FilePensionables.Include(x => x.EmployeeId)
        //        .FirstOrDefaultAsync(m => m.Id == id);
        //    if (fileManager == null)
        //    {
        //        return NotFound();
        //    }

        //    return View(fileManager);
        //}

        public async Task<IActionResult> Step0(int id)
        {
            FileUploadProcessController processController = this;
            int stepFound = 0;
            Pensionable pensionable = await processController._context.Pensionable.FindAsync((object)id);
            ViewBag.Pensionable = pensionable;
            List<FilePensionables> listAsync = await EntityFrameworkQueryableExtensions.ToListAsync<FilePensionables>(((IQueryable<FilePensionables>)processController._context.FilePensionables).Where<FilePensionables>((Expression<Func<FilePensionables, bool>>)(x => x.Step == stepFound && x.EmployeeId == id)), new CancellationToken());
            if (listAsync == null)
                return (IActionResult)processController.NotFound();
            return (IActionResult)processController.View((object)new TablePensionablesViewModel(id, 0)
            {
                FilesPensionable = listAsync
            });
        }

        [HttpPost("FileUploadProcess/Step0")]
        public async Task<IActionResult> Step0(TablePensionablesViewModel model, string action)
        {
            FileUploadProcessController processController = this;
            if (!processController.ModelState.IsValid)
                return (IActionResult)processController.View((object)model);
            ((IEnumerable<ControlTable>)processController._context.ControlTable).ToList<ControlTable>();
            Pensionable pensionable = await processController._context.Pensionable.FindAsync((object)model.EmployeeId);
            List<FilePensionables> listAsync = await EntityFrameworkQueryableExtensions.ToListAsync<FilePensionables>(((IQueryable<FilePensionables>)processController._context.FilePensionables).Where<FilePensionables>((Expression<Func<FilePensionables, bool>>)(x => x.EmployeeId == pensionable.Id && x.Step == 0)), new CancellationToken());
            processController.Pensionables = listAsync;
            switch (action)
            {
                case "Guardar":


                    if(model.checkPrePension!= null)
                    {
                        processController.HandleInfo(model.checkPrePension, 0, model.EmployeeId, 45, Tipos.prePension);
                    }
                    else 
                        await processController.HandleFile(model.prePension, 0, model.EmployeeId, 45, Tipos.prePension);

                    if (model.checkSituacionFiscal != null)
                    {
                        processController.HandleInfo(model.checkSituacionFiscal, 0, model.EmployeeId, 48, Tipos.SituacionFiscal);
                    }
                    else
                        await processController.HandleFile(model.SituacionFiscal, 0, model.EmployeeId, 48, Tipos.SituacionFiscal);



                    await processController.HandleFile(model.HojaAportacion, 0, model.EmployeeId, 9, Tipos.HojaAportacion);
                    await processController.HandleFile(model.CartaCompromiso, 0, model.EmployeeId, 15, Tipos.CartaCompromiso);
                    await processController.HandleFile(model.SituacionFiscal, 0, model.EmployeeId, 48, Tipos.SituacionFiscal);

                   
                    int num2 = await processController._context.SaveChangesAsync(new CancellationToken());
                    return (IActionResult)processController.RedirectToAction(nameof(Step0), (object)new
                    {
                        id = model.EmployeeId
                    });
                case "Avanzar":
                    if (await processController.HandleCreation(processController.Pensionables, 0, model.EmployeeId))
                    {
                        pensionable.Status = StatusPensionable.Step1;
                        int num3 = await processController._context.SaveChangesAsync(new CancellationToken());
                        break;
                    }
                    processController.TempData["Advertencia"] = (object)"Faltan documentos por cargar";
                    return (IActionResult)processController.RedirectToAction(nameof(Step0), (object)new
                    {
                        id = model.EmployeeId
                    });
            }
            return (IActionResult)processController.Redirect("Step1A/" + model.EmployeeId.ToString());

        }

        public async Task<IActionResult> Step1A(int id)
        {
            FileUploadProcessController processController = this;
            int stepFound = 1;
            Pensionable pensionable = await processController._context.Pensionable.FindAsync((object)id);
            ViewBag.Pensionable = pensionable;
            List<FilePensionables> listAsync = await EntityFrameworkQueryableExtensions.ToListAsync<FilePensionables>(((IQueryable<FilePensionables>)processController._context.FilePensionables).Where<FilePensionables>((Expression<Func<FilePensionables, bool>>)(x => x.Step == stepFound && x.EmployeeId == id)), new CancellationToken());
            if (listAsync == null)
                return (IActionResult)processController.NotFound();
            return (IActionResult)processController.View((object)new TablePensionablesViewModel(id, 1)
            {
                FilesPensionable = listAsync
            });
        }

        [HttpPost("FileUploadProcess/Step1A")]
        public async Task<IActionResult> Step1A(TablePensionablesViewModel model, string action)
        {
            FileUploadProcessController processController = this;
            if (!processController.ModelState.IsValid)
                return (IActionResult)processController.View((object)model);
            
            ((IEnumerable<ControlTable>)processController._context.ControlTable).ToList<ControlTable>();
            Pensionable pensionable = await processController._context.Pensionable.FindAsync((object)model.EmployeeId);
            List<FilePensionables> listAsync = await EntityFrameworkQueryableExtensions.ToListAsync<FilePensionables>(((IQueryable<FilePensionables>)processController._context.FilePensionables).Where<FilePensionables>((Expression<Func<FilePensionables, bool>>)(x => x.EmployeeId == pensionable.Id && x.Step == 1)), new CancellationToken());
            processController.Pensionables = listAsync;
            if (model.ClasePension != "Seleccionar ...")
                processController.HandleInfo(model.ClasePension, 1, model.EmployeeId, 1, Tipos.ClasePension);
            int num1 = await processController._context.SaveChangesAsync(new CancellationToken());
            switch (action)
            {
                case "Guardar":
                    await processController.HandleFile(model.FichaTecnica, 1, model.EmployeeId, 2, Tipos.FichaTecnica);
                    await processController.HandleFile(model.CartaAlcalde, 1, model.EmployeeId, 3, Tipos.CartaAlcalde);
                    await processController.HandleFile(model.FormatoIngreso, 1, model.EmployeeId, 4, Tipos.FormatoIngreso);
                    //await processController.HandleFile(model.StatusGenerales, 1, model.EmployeeId, 5, Tipos.StatusGenerales);
                    await processController.HandleFile(model.SolicitudISSSTESON, 1, model.EmployeeId, 6, Tipos.SolicitudISSSTESON);
                    await processController.HandleFile(model.ActaNacimiento, 1, model.EmployeeId, 7, Tipos.ActaNacimiento);
                    await processController.HandleFile(model.HojaServicio, 1, model.EmployeeId, 8, Tipos.HojaServicio);
                    //await processController.HandleFile(model.Foto, 1, model.EmployeeId, 9, Tipos.Foto);
                    await processController.HandleFile(model.CURP, 1, model.EmployeeId, 10, Tipos.CURP);
                    await processController.HandleFile(model.INE, 1, model.EmployeeId, 11, Tipos.INE);
                    await processController.HandleFile(model.Talon, 1, model.EmployeeId, 12, Tipos.Talon);
                    await processController.HandleFile(model.DictamenMed, 1, model.EmployeeId, 12, Tipos.DictamenMed);

                    if (model.checkRFC != null)
                    {
                        processController.HandleInfo(model.checkRFC, 0, model.EmployeeId, 13, Tipos.RFC);
                    }
                    else
                        await processController.HandleFile(model.RFC, 0, model.EmployeeId, 13, Tipos.RFC);

                    await processController.HandleFile(model.HojaAyuntamiento, 1, model.EmployeeId, 14, Tipos.HojaAyuntamiento);

                    int num2 = await processController._context.SaveChangesAsync(new CancellationToken());
                    return (IActionResult)processController.RedirectToAction(nameof(Step1A), (object)new
                    {
                        id = model.EmployeeId
                    });
                case "Crear":
                    if (await processController.HandleCreation(processController.Pensionables, 1, model.EmployeeId))
                    {
                        pensionable.Status = StatusPensionable.Step2;
                        int num3 = await processController._context.SaveChangesAsync(new CancellationToken());
                        break;
                    }
                    processController.TempData["Advertencia"] = (object)"Faltan documentos por cargar";
                    return (IActionResult)processController.RedirectToAction(nameof(Step1A), (object)new
                    {
                        id = model.EmployeeId
                    });
            }
            return (IActionResult)processController.Redirect("/Pensionable/Details/" + model.EmployeeId.ToString());
        }

        public async Task<IActionResult> Step2(int id)
        {
            FileUploadProcessController processController = this;
            int stepFound = 2;
            Pensionable pensionable = await processController._context.Pensionable.FindAsync((object)id);
            ViewBag.Pensionable = pensionable;
            List<FilePensionables> listAsync = await EntityFrameworkQueryableExtensions.ToListAsync<FilePensionables>(((IQueryable<FilePensionables>)processController._context.FilePensionables).Where<FilePensionables>((Expression<Func<FilePensionables, bool>>)(x => x.Step == stepFound && x.EmployeeId == id)), new CancellationToken());
            if (listAsync == null)
                return (IActionResult)processController.NotFound();
            return (IActionResult)processController.View((object)new TablePensionablesViewModel(id, 2)
            {
                FilesPensionable = listAsync
            });
        }

        [HttpPost("FileUploadProcess/Step2")]
        public async Task<IActionResult> Step2(TablePensionablesViewModel model, string action)
        {
            FileUploadProcessController processController = this;
            if (!processController.ModelState.IsValid)
                return (IActionResult)processController.View((object)model);
            ((IEnumerable<ControlTable>)processController._context.ControlTable).ToList<ControlTable>();
            Pensionable pensionable = await processController._context.Pensionable.FindAsync((object)model.EmployeeId);
            List<FilePensionables> listAsync = await EntityFrameworkQueryableExtensions.ToListAsync<FilePensionables>(((IQueryable<FilePensionables>)processController._context.FilePensionables).Where<FilePensionables>((Expression<Func<FilePensionables, bool>>)(x => x.EmployeeId == pensionable.Id && x.Step == 2)), new CancellationToken());
            processController.Pensionables = listAsync;
            switch (action)
            {
                case "Guardar":
                    await processController.HandleFile(model.FichaPermiso, 2, model.EmployeeId, 1, Tipos.FichaPermiso);

                    if (model.checkNomed != null)
                    {
                        processController.HandleInfo(model.checkNomed, 2, model.EmployeeId, 4, Tipos.DictamenMed);
                    }
                    else
                        await processController.HandleFile(model.DictamenMed, 2, model.EmployeeId, 2, Tipos.DictamenMed);



                    await processController.HandleFile(model.IngresoPensiones, 2, model.EmployeeId, 3, Tipos.IngresoPensiones);

                    if (model.checkNoSindicato != null)
                    {
                        processController.HandleInfo(model.checkNoSindicato, 2, model.EmployeeId, 4, Tipos.NumeroSindicato);
                    }
                    else
                        processController.HandleInfo(model.NumeroSindicato, 2, model.EmployeeId, 5, Tipos.NumeroSindicato);



                    if (model.TipoPension != "Seleccionar ...")
                        processController.HandleInfo(model.TipoPension, 2, model.EmployeeId, 4, Tipos.TipoPension);
                    if (model.FechaPermisoPreJubilatorio != null)
                        processController.HandleInfo(model.FechaPermisoPreJubilatorio, 2, model.EmployeeId, 5, Tipos.FechaPermisoPreJubilatorio);
                    int num1 = await processController._context.SaveChangesAsync(new CancellationToken());
                    return (IActionResult)processController.RedirectToAction(nameof(Step2), (object)new
                    {
                        id = model.EmployeeId
                    });
                case "Crear":
                    if (await processController.HandleCreation(processController.Pensionables, 2, model.EmployeeId))
                    {
                        pensionable.Status = StatusPensionable.Step3;
                        int num2 = await processController._context.SaveChangesAsync(new CancellationToken());
                        break;
                    }
                    processController.TempData["Advertencia"] = (object)"Faltan documentos por cargar";
                    return (IActionResult)processController.RedirectToAction(nameof(Step2), (object)new
                    {
                        id = model.EmployeeId
                    });
            }

            return (IActionResult)processController.Redirect("/Pensionable/Details/" + model.EmployeeId.ToString());
        }

        // GET: FileUploadProcess/Create
        public async Task<IActionResult> Step3(int id)
        {
            FileUploadProcessController processController = this;
            Pensionable pensionable = await processController._context.Pensionable.FindAsync((object)id);
            ViewBag.Pensionable = pensionable;
            int stepFound = 3;

            var filesPensionable = await _context.FilePensionables
                .Where(x => x.Step == stepFound && x.EmployeeId == id)
                .ToListAsync();

            if (filesPensionable == null)
            {
                return NotFound();
            }
            
            TablePensionablesViewModel model = new TablePensionablesViewModel(id, 3);
            model.FilesPensionable = filesPensionable;
            return View(model);

        }

        // POST: FileUploadProcess/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost("FileUploadProcess/Step3")]
        public async Task<IActionResult> Step3(TablePensionablesViewModel model, string action)
        {
            if (!ModelState.IsValid)
                return View(model);

            var ListControl = _context.ControlTable.ToList();

            var pensionable = await _context.Pensionable
                .FindAsync(model.EmployeeId);

            Pensionables = await _context.FilePensionables
                                 .Where(x => x.EmployeeId == pensionable.Id && x.Step == 3)
                                 .ToListAsync();

            if (action == "Guardar")
            {
                HandleInfo(model.Analisis, 3, model.EmployeeId, 1, Tipos.Analisis);
                HandleInfo(model.Dictamen, 3, model.EmployeeId, 2, Tipos.Dictamen);
                HandleInfo(model.TrabajoSocial, 3, model.EmployeeId, 3, Tipos.TrabajoSocial);
                HandleInfo(model.Juridico, 3, model.EmployeeId, 4, Tipos.Juridico);
                HandleInfo(model.ProcesoResolucion, 3, model.EmployeeId, 5, Tipos.ProcesoResolucion);
                HandleInfo(model.AprobadoJunta, 3, model.EmployeeId, 6, Tipos.AprobadoJunta);
                HandleInfo(model.PrimerPago, 3, model.EmployeeId, 7, Tipos.PrimerPago);

                await _context.SaveChangesAsync();

                return RedirectToAction(nameof(Step3), new { id = model.EmployeeId });

            }
            else if (action == "Crear")
            {
                bool allDocsExist = await HandleCreation(Pensionables, 3, model.EmployeeId);

                if (allDocsExist)
                {
                    pensionable.Status = StatusPensionable.Step4;
                    await _context.SaveChangesAsync();
                }
                else
                {
                    TempData["Advertencia"] = "Faltan documentos por cargar";
                    return RedirectToAction(nameof(Step3), new { id = model.EmployeeId });
                }
            }
            return Redirect("/Pensionable/Details/" + model.EmployeeId);
        }

        // GET: FileUploadProcess/Create
        public async Task<IActionResult> Step4(int id)
        {
            int stepFound = 4;
            FileUploadProcessController processController = this;
            Pensionable pensionable = await processController._context.Pensionable.FindAsync((object)id);
            ViewBag.Pensionable = pensionable;
            var filesPensionable = await _context.FilePensionables
                .Where(x => x.Step == stepFound && x.EmployeeId == id)
                .ToListAsync();

            if (filesPensionable == null)
            {
                return NotFound();
            }

            TablePensionablesViewModel model = new TablePensionablesViewModel(id, 1);
            model.FilesPensionable = filesPensionable;
            return View(model);

        }

        // POST: FileUploadProcess/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost("FileUploadProcess/Step4")]
        public async Task<IActionResult> Step4(TablePensionablesViewModel model, string action)
        {
            if (!ModelState.IsValid)
                return View(model);

            var ListControl = _context.ControlTable.ToList();

            var pensionable = await _context.Pensionable
                .FindAsync(model.EmployeeId);

            Pensionables = await _context.FilePensionables
                                 .Where(x => x.EmployeeId == pensionable.Id && x.Step == 4)
                                 .ToListAsync();

            if (action == "Guardar")
            {
                await HandleFile(model.AcuerdoAdmin, 4, model.EmployeeId, 1, Tipos.AcuerdoAdmin);
                await HandleFile(model.SolicitudJuridica, 4, model.EmployeeId, 2, Tipos.SolicitudJuridica);

                await _context.SaveChangesAsync();

                return RedirectToAction(nameof(Step4), new { id = model.EmployeeId });

            }
            else if (action == "Crear")
            {
                bool allDocsExist = await HandleCreation(Pensionables, 4, model.EmployeeId);

                if (allDocsExist)
                {
                    pensionable.Status = StatusPensionable.Step6;
                    await _context.SaveChangesAsync();
                }
                else
                {
                    TempData["Advertencia"] = "Faltan documentos por cargar";
                    return RedirectToAction(nameof(Step4), new { id = model.EmployeeId });
                }
            }
            return Redirect("/Pensionable/Details/" + model.EmployeeId);
        }

        //// GET: FileUploadProcess/Create
        //public async Task<IActionResult> Step5(int id)
        //{
        //    int stepFound = 5;
        //    FileUploadProcessController processController = this;
        //    Pensionable pensionable = await processController._context.Pensionable.FindAsync((object)id);
        //    ViewBag.Pensionable = pensionable;
        //    var filesPensionable = await _context.FilePensionables
        //        .Where(x => x.Step == stepFound && x.EmployeeId == id)
        //        .ToListAsync();

        //    if (filesPensionable == null)
        //    {
        //        return NotFound();
        //    }

        //    TablePensionablesViewModel model = new TablePensionablesViewModel(id, 1);
        //    model.FilesPensionable = filesPensionable;
        //    return View(model);

        //}

        //// POST: FileUploadProcess/Create
        //// To protect from overposting attacks, enable the specific properties you want to bind to, for 
        //// more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        //[HttpPost("FileUploadProcess/Step5")]
        //public async Task<IActionResult> Step5(TablePensionablesViewModel model, string action)
        //{
        //    if (!ModelState.IsValid)
        //        return View(model);

        //    var ListControl = _context.ControlTable.ToList();

        //    var pensionable = await _context.Pensionable
        //        .FindAsync(model.EmployeeId);

        //    Pensionables = await _context.FilePensionables
        //                         .Where(x => x.EmployeeId == pensionable.Id && x.Step == 5)
        //                         .ToListAsync();

        //    if (action == "Guardar")
        //    {
        //        await HandleFile(model.TurnarJuridicoRH, 5, model.EmployeeId, 1, Tipos.TurnarJuridicoRH);

        //        await _context.SaveChangesAsync();

        //        return RedirectToAction(nameof(Step5), new { id = model.EmployeeId });

        //    }
        //    else if (action == "Crear")
        //    {
        //        bool allDocsExist = await HandleCreation(Pensionables, 5, model.EmployeeId);

        //        if (allDocsExist)
        //        {
        //            pensionable.Status = StatusPensionable.Step6;
        //            await _context.SaveChangesAsync();
        //        }
        //        else
        //        {
        //            TempData["Advertencia"] = "Faltan documentos por cargar";
        //            return RedirectToAction(nameof(Step5), new { id = model.EmployeeId });
        //        }
        //    }
        //    return Redirect("/Pensionable/Details/" + model.EmployeeId);
        //}

        // GET: FileUploadProcess/Create
        public async Task<IActionResult> Step6(int id)
        {
            int stepFound = 6;
            FileUploadProcessController processController = this;
            Pensionable pensionable = await processController._context.Pensionable.FindAsync((object)id);
            ViewBag.Pensionable = pensionable;
            var filesPensionable = await _context.FilePensionables
                .Where(x => x.Step == stepFound && x.EmployeeId == id)
                .ToListAsync();

            if (filesPensionable == null)
            {
                return NotFound();
            }

            TablePensionablesViewModel model = new TablePensionablesViewModel(id, 6);
            model.FilesPensionable = filesPensionable;
            return View(model);

        }

        // POST: FileUploadProcess/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost("FileUploadProcess/Step6")]
        public async Task<IActionResult> Step6(TablePensionablesViewModel model, string action)
        {
            if (!ModelState.IsValid)
                return View(model);

            var ListControl = _context.ControlTable.ToList();

            var pensionable = await _context.Pensionable
                .FindAsync(model.EmployeeId);

            Pensionables = await _context.FilePensionables
                                 .Where(x => x.EmployeeId == pensionable.Id && x.Step == 6)
                                 .ToListAsync();

            if (action == "Guardar")
            {
                await HandleFile(model.InformarBaja, 6, model.EmployeeId, 1, Tipos.InformarBaja);
                await HandleFile(model.OpinionJuridica, 6, model.EmployeeId, 2, Tipos.OpinionJuridica);
                HandleInfo(model.TurnarAsuntosLaborales, 6, model.EmployeeId, 3, Tipos.TurnarAsuntosLaborales);
                //HandleInfo(model.MontoPension, 6, model.EmployeeId, 47, Tipos.MontoPension);

                if (model.SolicitudReunion != null)
                    await HandleFile(model.SolicitudReunion, 6, model.EmployeeId, 4, Tipos.SolicitudReunion);

                else if (model.SolicitudReunionNA != null)
                    HandleInfo(model.SolicitudReunionNA, 6, model.EmployeeId, 4, Tipos.SolicitudReunion);
                

                await _context.SaveChangesAsync();

                return RedirectToAction(nameof(Step6), new { id = model.EmployeeId });

            }
            else if (action == "Crear")
            {
                bool allDocsExist = await HandleCreation(Pensionables, 6, model.EmployeeId);

                if (allDocsExist)
                {
                    pensionable.Status = StatusPensionable.Step7;
                    await _context.SaveChangesAsync();
                }
                else
                {
                    TempData["Advertencia"] = "Faltan documentos por cargar";
                    return RedirectToAction(nameof(Step6), new { id = model.EmployeeId });
                }
            }
            return Redirect("/Pensionable/Details/" + model.EmployeeId);
        }

        // GET: FileUploadProcess/Create
        public async Task<IActionResult> Step7(int id)
        {
            int stepFound = 7;
            FileUploadProcessController processController = this;
            Pensionable pensionable = await processController._context.Pensionable.FindAsync((object)id);
            ViewBag.Pensionable = pensionable;
            var filesPensionable = await _context.FilePensionables
                .Where(x => x.Step == stepFound && x.EmployeeId == id)
                .ToListAsync();

            if (filesPensionable == null)
            {
                return NotFound();
            }

            TablePensionablesViewModel model = new TablePensionablesViewModel(id, 7);
            model.FilesPensionable = filesPensionable;
            return View(model);

        }

        // POST: FileUploadProcess/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost("FileUploadProcess/Step7")]
        public async Task<IActionResult> Step7(TablePensionablesViewModel model, string action)
        {
            if (!ModelState.IsValid)
                return View(model);

            var ListControl = _context.ControlTable.ToList();

            var pensionable = await _context.Pensionable
                .FindAsync(model.EmployeeId);

            Pensionables = await _context.FilePensionables
                                 .Where(x => x.EmployeeId == pensionable.Id && x.Step == 7)
                                 .ToListAsync();

            if (action == "Guardar")
            {
                await HandleFile(model.RespuestaJuridica, 7, model.EmployeeId, 1, Tipos.RespuestaJuridica);
                await HandleFile(model.RecepcionCabildo, 7, model.EmployeeId, 2, Tipos.RecepcionCabildo);
                await HandleFile(model.InfAreaAlta, 7, model.EmployeeId, 3, Tipos.InfAreaAlta);

                if (model.FondoRetiro != null)
                    await HandleFile(model.FondoRetiro, 7, model.EmployeeId, 4, Tipos.FondoRetiro);

                else if (model.FondoRetiroNA != null)
                    HandleInfo(model.FondoRetiroNA, 7, model.EmployeeId, 4, Tipos.FondoRetiro);

                await _context.SaveChangesAsync();

                return RedirectToAction(nameof(Step7), new { id = model.EmployeeId });

            }
            else if (action == "Crear")
            {
                bool allDocsExist = await HandleCreation(Pensionables, 7, model.EmployeeId);

                if (allDocsExist)
                {
                    pensionable.Status = StatusPensionable.Step8;
                    await _context.SaveChangesAsync();
                }
                else
                {
                    TempData["Advertencia"] = "Faltan documentos por cargar";
                    return RedirectToAction(nameof(Step7), new { id = model.EmployeeId });
                }
            }
            return Redirect("/Pensionable/Details/" + model.EmployeeId);
        }

        // GET: FileUploadProcess/Create
        public async Task<IActionResult> Step8(int id)
        {
            int stepFound = 8;
            FileUploadProcessController processController = this;
            Pensionable pensionable = await processController._context.Pensionable.FindAsync((object)id);
            ViewBag.Pensionable = pensionable;
            var filesPensionable = await _context.FilePensionables
                .Where(x => x.Step == stepFound && x.EmployeeId == id)
                .ToListAsync();

            if (filesPensionable == null)
            {
                return NotFound();
            }

            TablePensionablesViewModel model = new TablePensionablesViewModel(id, 8);
            model.FilesPensionable = filesPensionable;
            return View(model);

        }

        // POST: FileUploadProcess/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost("FileUploadProcess/Step8")]
        public async Task<IActionResult> Step8(TablePensionablesViewModel model)
        {
            if (!ModelState.IsValid)
                return View(model);

            var pensionable = await _context.Pensionable
                .FindAsync(model.EmployeeId);

            pensionable.Status = StatusPensionable.Step9;

            await _context.SaveChangesAsync();
            return Redirect("/Pensionable/index");
        }

        async Task<bool> CreateFile(string fileName, IFormFile file) //, FileTypes fileType)

        {
            if (file.Length == 0)
                return false;

            var filePath = Path.Combine("wwwroot/", fileName);

            using (var stream = System.IO.File.Create(filePath))
            {
                await file.CopyToAsync(stream);
            }
            return true;
        }

        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var FilesStep1 = await _context.FilePensionables
                .FirstOrDefaultAsync(m => m.Id == id);
            if (FilesStep1 == null)
            {
                return NotFound();
            }

            return View(FilesStep1);
        }
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }


            var filesPensionable = await _context.FilePensionables
                .FirstOrDefaultAsync(m => m.Id == id);

            if (filesPensionable == null)
            {
                return NotFound();
            }

            return View(filesPensionable);
        }

        [HttpPost("FileUploadProcess/Edit")]
        public async Task<IActionResult> Edit(FilePensionables model, string action)
        {

            var ListControl = _context.ControlTable.ToList();

            //var pensionable = await _context.Pensionable
            //    .FindAsync(model.EmployeeId);

            Pensionables = await _context.FilePensionables
                                 .Where(x => x.Id == model.Id)
                                 .ToListAsync();

            if (action == "Modificar")
            {
                await HandleFile(model.file, model.Step, model.EmployeeId, model.Number, model.Tipo);

                await _context.SaveChangesAsync();

                //return RedirectToAction(nameof(Edit), new { id = model.Id });

            }


            //FileUploadProcessController processController = this;
            //((IEnumerable<ControlTable>)processController._context.ControlTable).ToList<ControlTable>();
            //Pensionable pensionable = await processController._context.Pensionable.FindAsync((object)model.EmployeeId);
            //List<FilePensionables> listAsync = await EntityFrameworkQueryableExtensions.ToListAsync<FilePensionables>(((IQueryable<FilePensionables>)processController._context.FilePensionables).Where<FilePensionables>((Expression<Func<FilePensionables, bool>>)(x => x.EmployeeId == pensionable.Id && x.Id == model.Id)), new CancellationToken());
            //processController.Pensionables = listAsync;

            ////if (action == "Guardar")
            ////{

            //    await processController.HandleFile(model.file, model.Step, model.EmployeeId, model.Number, model.Tipo);


            //    int num2 = await processController._context.SaveChangesAsync(new CancellationToken());

            //    //return RedirectToAction(nameof(Edit), new { id = model.Id });

            //    //if (await processController.HandleCreation(processController.Pensionables, model.Step, model.EmployeeId))
            //    //{
            //    //    //pensionable.Status = StatusPensionable.;
            //    //    int num3 = await processController._context.SaveChangesAsync(new CancellationToken());
            //    //}

            ////}
            ////return (IActionResult)processController.Redirect("Details/" + model.Id.ToString());
            return Redirect("Details/" + model.Id.ToString());

        }






        private void HandleInfo(string info, int step, int employeeId, int number, Tipos tipo)
        {
            var existingDoc = Pensionables
                .SingleOrDefault(x => x.Tipo == tipo);

            if (info != null)
            {
                if (existingDoc != null)
                {
                    _context.Entry(existingDoc).State = EntityState.Modified;
                }
                else
                {
                    existingDoc = new FilePensionables();
                    _context.Add(existingDoc);
                }
                existingDoc.Step = step;
                existingDoc.Tipo = tipo;
                existingDoc.NameDoc = tipo.ToString();
                existingDoc.EmployeeId = employeeId;
                existingDoc.Number = number;
                existingDoc.Info = info;
                existingDoc.IsFile = false;
            }

        }

        private async Task HandleFile(IFormFile file, int step, int employeeId, int number, Tipos tipo)
        {
            string guid;
            FilePensionables existingDoc;
            if (file == null)
            {
                guid = (string)null;
                existingDoc = (FilePensionables)null;
            }
            else
            {
                guid = Guid.NewGuid().ToString() + Path.GetExtension(file.FileName);
                existingDoc = this.Pensionables.SingleOrDefault<FilePensionables>((Func<FilePensionables, bool>)(x => x.Tipo == tipo));
                if (existingDoc != null)
                {
                    this._context.Entry<FilePensionables>(existingDoc).State = EntityState.Modified;
                }
                else
                {
                    existingDoc = new FilePensionables();
                    this._context.Add<FilePensionables>(existingDoc);
                }
                int num = await this.CreateFile(guid, file) ? 1 : 0;
                existingDoc.Step = step;
                existingDoc.Tipo = tipo;
                existingDoc.NameDoc = tipo.ToString();
                existingDoc.EmployeeId = employeeId;
                existingDoc.Number = number;
                existingDoc.Info = guid;
                existingDoc.IsFile = true;
                guid = (string)null;
                existingDoc = (FilePensionables)null;
            }
        }

        private async Task<bool> HandleCreation(List<FilePensionables> model, int step, int id)
        {
            List<ControlTable> list = ((IEnumerable<ControlTable>)this._context.ControlTable).ToList<ControlTable>();
            bool flag1 = true;
            
            foreach (ControlTable controlTable in list)
            {
                if (!controlTable.NecesaryStep1)//NotNecesary
                {
                    flag1 = true;
                    break;
                }
                if (controlTable.Step == step)
                {
                    bool flag2 = false;
                    foreach (FilePensionables filePensionables in model)
                    {
                        if (filePensionables.NameDoc == controlTable.Name)
                        {
                            flag2 = true;
                            break;
                        }
                    }
                    if (!flag2)
                    {
                        flag1 = false;
                        break;
                    }
                    /*break*/;
                }
                
                //{
                //    bool flag3 = false;
                //    foreach (FilePensionables filePensionables in model)
                //    {
                //        if (filePensionables.NameDoc == controlTable.Name)
                //        {
                //            flag3 = true;
                //            break;
                //        }
                //    }
                //    if (!flag3)
                //    {
                //        flag1 = false;
                //        break;
                //    }
                //    break;
                //}
            }
            return flag1;
        }

        private Tipos GetTipos(string tipo)
        {
            return tipo switch
            {
                "ClasePension" => Tipos.ClasePension,
                "FichaTecnica" => Tipos.FichaTecnica,
                "CartaAlcalde" => Tipos.CartaAlcalde,
                "FormatoIngreso" => Tipos.FormatoIngreso,
                "StatusGenerales" => Tipos.StatusGenerales,
                "SolicitudISSSTESON" => Tipos.SolicitudISSSTESON,
                "ActaNacimiento" => Tipos.ActaNacimiento,
                "HojaServicio" => Tipos.HojaServicio,
                "HojaAportacion" => Tipos.HojaAportacion,
                "Foto" => Tipos.Foto,
                "CURP" => Tipos.CURP,
                "INE" => Tipos.INE,
                "Talon" => Tipos.Talon,
                "RFC" => Tipos.RFC,
                "CartaCompromiso" => Tipos.CartaCompromiso,
                "HojaAyuntamiento" => Tipos.HojaAyuntamiento,
                "FichaPermiso" => Tipos.FichaPermiso,
                "IngresoPensiones" => Tipos.IngresoPensiones,
                "NumeroSindicato" => Tipos.NumeroSindicato,
                "TipoPension" => Tipos.TipoPension,
                "FechaPermisoPreJubilatorio" => Tipos.FechaPermisoPreJubilatorio,
                "Analisis" => Tipos.Analisis,
                "Dictamen" => Tipos.Dictamen,
                "TrabajoSocial" => Tipos.TrabajoSocial,
                "Juridico" => Tipos.Juridico,
                "ProcesoResolucion" => Tipos.ProcesoResolucion,
                "AprobadoJunta" => Tipos.AprobadoJunta,
                "PrimerPago" => Tipos.PrimerPago,
                "AcuerdoAdmin" => Tipos.AcuerdoAdmin,
                "SolicitudJuridica" => Tipos.SolicitudJuridica,
                "TurnarJuridicoRH" => Tipos.TurnarJuridicoRH,
                "InformarBaja" => Tipos.InformarBaja,
                "OpinionJuridica" => Tipos.OpinionJuridica,
                "TurnarAsuntosLaborales" => Tipos.TurnarAsuntosLaborales,
                "SolicitudReunion" => Tipos.SolicitudReunion,
                "FondoRetiro" => Tipos.FondoRetiro,
                _ => throw new Exception()
            };
        }

    }
}
