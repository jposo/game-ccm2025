﻿//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Threading.Tasks;
//using Microsoft.AspNetCore.Mvc;
//using Microsoft.AspNetCore.Mvc.Rendering;
//using Microsoft.EntityFrameworkCore;
//using GenericProject.Data;
//using GenericProject.Models;
//using System.IO;
//using Microsoft.EntityFrameworkCore.Metadata.Internal;
//using static Microsoft.EntityFrameworkCore.DbLoggerCategory;
//using Microsoft.AspNetCore.Http;

//namespace GenericProject.Controllers
//{
//    public class FilesPensionablesController : Controller
//    {
//        private readonly ApplicationContext _context;

//        public FilesPensionablesController(ApplicationContext context)
//        {
//            _context = context;
//        }

//        // GET: FilesPensionables
//        public async Task<IActionResult> Index()
//        {
//            var model = await _context.FilesPensionables
//                                      .Include(x => x.Pensionable)
//                                      .ToListAsync();

//            return View(model);
//            //var applicationContext = _context.FilesPensionables.Include(l => l.appointment);


//        }

//        // GET: FilesPensionables/Details/5
//        public async Task<IActionResult> Details(int? id)
//        {
//            if (id == null)
//            {
//                return NotFound();
//            }

//            var FilesPensionables = await _context.FilesPensionables
//                .FirstOrDefaultAsync(m => m.Id == id);
//            if (FilesPensionables == null)
//            {
//                return NotFound();
//            }

//            return View(FilesPensionables);
//        }

//        // GET: FilesPensionables/Create}
//        public IActionResult Create(int id)
//        {
//            FilesPensionables model = new FilesPensionables();
//            return View(model);

//        }

//        // POST: FilesPensionables/Create
//        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
//        // more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
//        [HttpPost("FilesPensionables/Create")]
//        public async Task<IActionResult> Create(FilesPensionables FilesPensionables)
//        {
//            if (ModelState.IsValid)
//            {
//                if (FilesPensionables.DocFichaTecnica.Length > 0)
//                {
//                    var filePath = Path.Combine("wwwroot/", FilesPensionables.DocFichaTecnica.FileName);

//                    using (var stream = System.IO.File.Create(filePath))
//                    {
//                        await FilesPensionables.DocFichaTecnica.CopyToAsync(stream);
//                    }
//                }
//                FilesPensionables.FileINE = FilesPensionables.DocFichaTecnica.FileName;
//                _context.Add(FilesPensionables);
//                await _context.SaveChangesAsync();
//                return Redirect("/FilesPensionables/Index/" + FilesPensionables.Pensionable.Id);
//            }


//            return View(FilesPensionables);
//        }

//        public IActionResult Step1(int id)
//        {
//            FilesPensionables model = new FilesPensionables();
//            model.EmployeeId = id;
//            return View(model);

//        }

//        [HttpPost("FilesPensionables/Step1")]
//        public async Task<IActionResult> Step1(FilesPensionables model)
//        {
//            if (ModelState.IsValid)
//            {
//                var pensionable = await _context.Pensionable.FindAsync(model.EmployeeId);

//                if (pensionable == null)
//                {
//                    ModelState.AddModelError("", "Pensionable no encontrado");
//                    return View(model);
//                }
//                model.Pensionable = pensionable;
//                model.EmployeeNumber = pensionable.EmployeeNumber;

//                if (model.DocFichaTecnica.Length > 0 && model.DocCartaAlcalde.Length > 0 && model.DocFormatoIngreso.Length > 0
//                    && model.DocEstatusGenerales.Length > 0 && model.DocSolicitudIsssteson.Length > 0 && model.DocActaNacimiento.Length > 0
//                    && model.DocHojaServicio.Length > 0 && model.DocHojaAportacion.Length > 0 && model.DocFoto.Length > 0
//                    && model.DocCURP.Length > 0 && model.DocINE.Length > 0 && model.DocTalon.Length > 0
//                    && model.DocRFC.Length > 0 && model.ClassPension == "Vejez")
//                {
//                    var filePath = Path.Combine("wwwroot/", model.DocFichaTecnica.FileName);
//                    var filePath2 = Path.Combine("wwwroot/", model.DocCartaAlcalde.FileName);
//                    var filePath3 = Path.Combine("wwwroot/", model.DocFormatoIngreso.FileName);
//                    var filePath4 = Path.Combine("wwwroot/", model.DocEstatusGenerales.FileName);
//                    var filePath5 = Path.Combine("wwwroot/", model.DocSolicitudIsssteson.FileName);
//                    var filePath6 = Path.Combine("wwwroot/", model.DocActaNacimiento.FileName);
//                    var filePath7 = Path.Combine("wwwroot/", model.DocHojaServicio.FileName);
//                    var filePath8 = Path.Combine("wwwroot/", model.DocHojaAportacion.FileName);
//                    var filePath9 = Path.Combine("wwwroot/", model.DocFoto.FileName);
//                    var filePath10 = Path.Combine("wwwroot/", model.DocCURP.FileName);
//                    var filePath11 = Path.Combine("wwwroot/", model.DocINE.FileName);
//                    var filePath12 = Path.Combine("wwwroot/", model.DocTalon.FileName);
//                    var filePath13 = Path.Combine("wwwroot/", model.DocRFC.FileName);

//                    using (var stream = System.IO.File.Create(filePath))
//                    {
//                        await model.DocFichaTecnica.CopyToAsync(stream);
//                        await model.DocCartaAlcalde.CopyToAsync(stream);
//                        await model.DocFormatoIngreso.CopyToAsync(stream);
//                        await model.DocEstatusGenerales.CopyToAsync(stream);
//                        await model.DocSolicitudIsssteson.CopyToAsync(stream);
//                        await model.DocActaNacimiento.CopyToAsync(stream);
//                        await model.DocHojaServicio.CopyToAsync(stream);
//                        await model.DocHojaAportacion.CopyToAsync(stream);
//                        await model.DocFoto.CopyToAsync(stream);
//                        await model.DocCURP.CopyToAsync(stream);
//                        await model.DocINE.CopyToAsync(stream);
//                        await model.DocTalon.CopyToAsync(stream);
//                        await model.DocRFC.CopyToAsync(stream);
//                    }
//                }
//                else if (model.DocFichaTecnica.Length > 0 && model.DocCartaAlcalde.Length > 0 && model.DocFormatoIngreso.Length > 0
//                    && model.DocEstatusGenerales.Length > 0 && model.DocSolicitudIsssteson.Length > 0 && model.DocActaNacimiento.Length > 0
//                    && model.DocHojaServicio.Length > 0 && model.DocHojaAportacion.Length > 0 && model.DocFoto.Length > 0
//                    && model.DocCURP.Length > 0 && model.DocINE.Length > 0 && model.DocTalon.Length > 0
//                    && model.DocRFC.Length > 0 && model.DocCartaCompromiso.Length > 0 && model.DocHojaAyuntamiento.Length > 0
//                    && model.ClassPension == "Antigüedad")
//                {
//                    var filePath = Path.Combine("wwwroot/", model.DocFichaTecnica.FileName);
//                    var filePath2 = Path.Combine("wwwroot/", model.DocCartaAlcalde.FileName);
//                    var filePath3 = Path.Combine("wwwroot/", model.DocFormatoIngreso.FileName);
//                    var filePath4 = Path.Combine("wwwroot/", model.DocEstatusGenerales.FileName);
//                    var filePath5 = Path.Combine("wwwroot/", model.DocSolicitudIsssteson.FileName);
//                    var filePath6 = Path.Combine("wwwroot/", model.DocActaNacimiento.FileName);
//                    var filePath7 = Path.Combine("wwwroot/", model.DocHojaServicio.FileName);
//                    var filePath8 = Path.Combine("wwwroot/", model.DocHojaAportacion.FileName);
//                    var filePath9 = Path.Combine("wwwroot/", model.DocFoto.FileName);
//                    var filePath10 = Path.Combine("wwwroot/", model.DocCURP.FileName);
//                    var filePath11 = Path.Combine("wwwroot/", model.DocINE.FileName);
//                    var filePath12 = Path.Combine("wwwroot/", model.DocTalon.FileName);
//                    var filePath13 = Path.Combine("wwwroot/", model.DocRFC.FileName);
//                    var filePath14 = Path.Combine("wwwroot/", model.DocCartaCompromiso.FileName);
//                    var filePath15 = Path.Combine("wwwroot/", model.DocHojaAyuntamiento.FileName);

//                    using (var stream = System.IO.File.Create(filePath))
//                    {
//                        await model.DocFichaTecnica.CopyToAsync(stream);
//                        await model.DocCartaAlcalde.CopyToAsync(stream);
//                        await model.DocFormatoIngreso.CopyToAsync(stream);
//                        await model.DocEstatusGenerales.CopyToAsync(stream);
//                        await model.DocSolicitudIsssteson.CopyToAsync(stream);
//                        await model.DocActaNacimiento.CopyToAsync(stream);
//                        await model.DocHojaServicio.CopyToAsync(stream);
//                        await model.DocHojaAportacion.CopyToAsync(stream);
//                        await model.DocFoto.CopyToAsync(stream);
//                        await model.DocCURP.CopyToAsync(stream);
//                        await model.DocINE.CopyToAsync(stream);
//                        await model.DocTalon.CopyToAsync(stream);
//                        await model.DocRFC.CopyToAsync(stream);
//                        await model.DocCartaCompromiso.CopyToAsync(stream);
//                        await model.DocHojaAyuntamiento.CopyToAsync(stream);
//                    }
//                }

//                model.FileFichaTecnica = model.DocFichaTecnica.FileName;
//                model.FileCartaAlcalde = model.DocCartaAlcalde.FileName;
//                model.FileFormatoIngreso = model.DocCartaAlcalde.FileName;
//                model.FileEstatusGenerales = model.DocCartaAlcalde.FileName;
//                model.FileSolicitudIsssteson = model.DocCartaAlcalde.FileName;
//                model.FileActaNacimiento = model.DocCartaAlcalde.FileName;
//                model.FileHojaServicio = model.DocCartaAlcalde.FileName;
//                model.FileHojaAportacion = model.DocCartaAlcalde.FileName;
//                model.FileFoto = model.DocCartaAlcalde.FileName;
//                model.FileCURP = model.DocCartaAlcalde.FileName;
//                model.FileINE = model.DocCartaAlcalde.FileName;
//                model.FileTalon = model.DocCartaAlcalde.FileName;
//                model.FileRFC = model.DocCartaAlcalde.FileName;
//                model.FileCartaCompromiso = model.DocCartaAlcalde.FileName;
//                model.FileHojaAyuntamiento = model.DocCartaAlcalde.FileName;

//                _context.Add(model);

//                pensionable.Status = StatusPensionable.Step2;
//                await _context.SaveChangesAsync();

//                return Redirect("/Pensionable/Details/" + model.Pensionable.Id);
//            }

//            return View(model);
//        }

//        public IActionResult Step2(int id)
//        {
//            FilesPensionables model = _context.FilesPensionables.FirstOrDefault(f => f.EmployeeId == id);
//            return View(model);

//        }

//        async Task CreateFile(string fileName, IFormFile file) //, FileTypes fileType)

//        {
//            if (file.Length == 0)
//                return;

//            var filePath = Path.Combine("wwwroot/", fileName);

//            using var stream = System.IO.File.Create(filePath);

//            await file.CopyToAsync(stream);

//            //var fileModel = new FileModel
//            //{
//            //    FileType = fileType,
//            //    FileName = fileName,
//            //   //TODO: Katrina adds more fields here, using parameters and stuff
//            //};

//            //_context.Add(fileModel);
//        }

//        [HttpPost("FilesPensionables/Step2")]
//        public async Task<IActionResult> Step2(FilesPensionables model)
//        {
//            if (!ModelState.IsValid)
//                return View(model);

//            FilesPensionables filePensionable = await _context.FilesPensionables
//                .Include(f => f.Pensionable)
//                .FirstOrDefaultAsync(f => f.Id == model.Id);

//            await CreateFile(model.DocFichaPermiso.FileName, model.DocFichaPermiso);
//            await CreateFile(model.DocIngresoPermiso.FileName, model.DocIngresoPermiso);

//            filePensionable.FileFichaPermiso = model.DocFichaPermiso.FileName;
//            filePensionable.FileIngresoPermiso = model.DocIngresoPermiso.FileName;

//            filePensionable.Pensionable.Status = StatusPensionable.Step3;
//            await _context.SaveChangesAsync();
//            return Redirect("/Pensionable/Details/" + filePensionable.Pensionable.Id);
//        }

//        // GET: FilesPensionables/Edit/5
//        public async Task<IActionResult> Edit(int? id)
//        {
//            if (id == null)
//            {
//                return NotFound();
//            }

//            var FilesPensionables = await _context.FilesPensionables.FindAsync(id);
//            if (FilesPensionables == null)
//            {
//                return NotFound();
//            }
//            //ViewData["AppointmentId"] = new SelectList(_context.Appointment, "Id", "Id", FilesPensionables.AppointmentId);
//            return View(FilesPensionables);
//        }

//        // POST: FilesPensionables/Edit/5
//        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
//        // more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
//        [HttpPost]
//        [ValidateAntiForgeryToken]
//        public async Task<IActionResult> Edit(int id, [Bind("Id,nameDoc,Comment,AppointmentId")] FilesPensionables FilesPensionables)
//        {
//            if (id != FilesPensionables.Id)
//            {
//                return NotFound();
//            }

//            if (ModelState.IsValid)
//            {
//                try
//                {
//                    _context.Update(FilesPensionables);
//                    await _context.SaveChangesAsync();
//                }
//                catch (DbUpdateConcurrencyException)
//                {
//                    if (!FilesPensionablesExists(FilesPensionables.Id))
//                    {
//                        return NotFound();
//                    }
//                    else
//                    {
//                        throw;
//                    }
//                }
//                return RedirectToAction(nameof(Index));
//            }
//            ViewData["AppointmentId"] = new SelectList(_context.Appointment, "Id", "Id", FilesPensionables.Pensionable.Id);
//            return View(FilesPensionables);
//        }

//        // GET: FilesPensionables/Delete/5
//        public async Task<IActionResult> Delete(int? id)
//        {
//            if (id == null)
//            {
//                return NotFound();
//            }

//            var FilesPensionables = await _context.FilesPensionables
//                .FirstOrDefaultAsync(m => m.Id == id);
//            if (FilesPensionables == null)
//            {
//                return NotFound();
//            }

//            return View(FilesPensionables);
//        }

//        // POST: FilesPensionables/Delete/5
//        [HttpPost, ActionName("Delete")]
//        [ValidateAntiForgeryToken]
//        public async Task<IActionResult> DeleteConfirmed(int id)
//        {
//            var FilesPensionables = await _context.FilesPensionables.FindAsync(id);
//            _context.FilesPensionables.Remove(FilesPensionables);
//            await _context.SaveChangesAsync();
//            return Redirect("/FilesPensionables/Index/" + FilesPensionables.Pensionable.Id);
//        }



//        private bool FilesPensionablesExists(int id)
//        {
//            return _context.FilesPensionables.Any(e => e.Id == id);
//        }
//    }
//}
